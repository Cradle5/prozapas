# Дизайн-система Прозапас

## Цветовая шкала

| Роль | Светлая тема | Тёмная тема |
|---|---|---|
| primary | `0xFF6750A4` (брендовый фиолетовый) | `0xFFD0BCFF` |
| onPrimary | белый | `0xFF381E72` |
| primaryContainer | `0xFFEADDFF` | `0xFF4F378B` |
| secondary | `0xFF625B71` | `0xFFCCC2DC` |
| error | `0xFFB3261E` | `0xFFF2B8B5` |
| background/surface | `0xFFFDF8FD` | `0xFF1C1B1F` |
| surfaceVariant | `0xFFE7E0EC` | `0xFF49454F` |

Расширенные цвета (ExtendedColors, вне схемы Material):

| Цвет | Значение | Назначение |
|---|---|---|
| statusOk | `0xFF16A34A` | остаток в норме |
| statusLow | `0xFFD97706` | ниже минимума |
| statusOut | `0xFFDC2626` | нет в наличии |
| headerGradient | `0xFF1E3A8A → 0xFF5B9CF8` | градиент шапки |

## Типографика

| Стиль | Параметры | Использование |
|---|---|---|
| headlineMedium | 28sp, полужирный | заголовки экранов, имя профиля |
| titleLarge | 20sp, полужирный | шапка, секции |
| bodyLarge | 16sp, межстрочный 24sp | основной текст, строки списка |
| bodySmall | 12sp | второстепенные подписи |
| labelSmall | 11sp | бейджи статусов |

## Формы

| Форма | Радиус | Применение |
|---|---|---|
| small | 8dp | бейджи |
| medium | 16dp | карточки |
| large | 24dp | крупные карточки |

## Компоненты

- **AppButton** — `modifier` первый параметр; стили PRIMARY/SECONDARY/OUTLINED,
  размеры SMALL/MEDIUM/LARGE (contentPadding + размер шрифта), цвета из colorScheme.
- **StatusButton** — состояния IDLE/LOADING/ERROR/SUCCESS; в не-IDLE кнопка недоступна;
  семантика: stateDescription и contentDescription.
- **FormField** — состояния IDLE/ERROR/WARNING/DISABLED; ERROR — isError + текст ошибки,
  WARNING — жёлтая рамка, DISABLED — stateDescription «Недоступно».
- **LoadingButton** — isLoading показывает CircularProgressIndicator вместо текста.
- **ProfileCard** — слоты leadingIcon/trailingContent; `mergeDescendants = true`.
- **SnackbarLikeMessage** — живой регион LiveRegionMode.Assertive.
- **PulsingDots** — rememberInfiniteTransition, три точки со StartOffset.

## Доступность

- Все иконки в кнопках и IconButton имеют contentDescription, описывающий действие.
- Декоративные изображения — contentDescription = null.
- Кликабельные области — не менее 48×48dp.
- Состояния описаны через stateDescription, а не только цветом.
