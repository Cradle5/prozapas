package ru.prozapas

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ru.prozapas.data.FakeWarehouseRepository
import ru.prozapas.data.ProductStatus
import ru.prozapas.ui.viewmodel.PurchaseViewModel

@OptIn(ExperimentalCoroutinesApi::class)
class PurchaseViewModelTest {

    private val dispatcher = StandardTestDispatcher()
    private lateinit var repository: FakeWarehouseRepository
    private lateinit var viewModel: PurchaseViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        repository = FakeWarehouseRepository()
        viewModel = PurchaseViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `receive increases stock and clears cart`() {
        repository.initialLoad()
        dispatcher.scheduler.advanceUntilIdle()

        val before = repository.products.value.first { it.id == 1L }
        viewModel.addToCart(1L)
        val qty = viewModel.cart.value.getValue(1L)

        assertTrue(viewModel.receive("Тест"))

        val after = repository.products.value.first { it.id == 1L }
        assertEquals(before.stock + qty, after.stock, 1e-9)
        assertTrue(viewModel.cart.value.isEmpty())
    }

    @Test
    fun `autofill deficit fills only problem positions`() {
        repository.initialLoad()
        dispatcher.scheduler.advanceUntilIdle()

        viewModel.autofillDeficit()
        val byId = repository.products.value.associateBy { it.id }

        assertEquals(
            repository.products.value.count { it.status != ProductStatus.OK },
            viewModel.cart.value.size,
        )
        viewModel.cart.value.forEach { (id, qty) ->
            assertTrue(byId.getValue(id).status != ProductStatus.OK)
            assertTrue(qty >= 1.0)
        }
    }
}
