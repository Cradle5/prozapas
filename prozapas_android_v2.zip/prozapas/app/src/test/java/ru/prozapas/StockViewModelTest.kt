package ru.prozapas

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ru.prozapas.data.FakeWarehouseRepository
import ru.prozapas.ui.viewmodel.StockUiState
import ru.prozapas.ui.viewmodel.StockViewModel

@OptIn(ExperimentalCoroutinesApi::class)
class StockViewModelTest {

    private val dispatcher = StandardTestDispatcher()
    private lateinit var repository: FakeWarehouseRepository
    private lateinit var viewModel: StockViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        repository = FakeWarehouseRepository()
        viewModel = StockViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `load success - state becomes Success`() {
        viewModel.load()
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(viewModel.state.value is StockUiState.Success)
        assertEquals(60, viewModel.products.value.size)
    }

    @Test
    fun `load failure - retry brings Success`() {
        repository.failNextLoad = true
        viewModel.load()
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(viewModel.state.value is StockUiState.Error)

        viewModel.retry()
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(viewModel.state.value is StockUiState.Success)
    }

    @Test
    fun `double load - only one request reaches repository`() {
        viewModel.load()
        viewModel.load()
        dispatcher.scheduler.advanceUntilIdle()
        assertEquals(1, repository.loadCalls)
    }

    @Test
    fun `backoff delay grows with retry count`() {
        repository.failNextLoad = true
        viewModel.load()
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(viewModel.state.value is StockUiState.Error)

        repository.failNextLoad = true
        viewModel.retry()
        dispatcher.scheduler.advanceUntilIdle()

        val error = viewModel.state.value as StockUiState.Error
        assertEquals(2, error.retryCount)
        assertEquals(2000L, error.retryDelayMs)
    }
}
