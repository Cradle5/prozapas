package ru.prozapas.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ru.prozapas.data.OperationBus
import ru.prozapas.data.Product
import ru.prozapas.data.ProductStatus
import ru.prozapas.data.WarehouseRepository
import ru.prozapas.ui.util.formatRub
import kotlin.math.ceil
import kotlin.math.max

@androidx.compose.runtime.Immutable
data class PurchaseEntry(val product: Product, val qty: Double)

/** ViewModel заявки на закупку: корзина, автозаполнение дефицита, приход. */
class PurchaseViewModel(private val repository: WarehouseRepository) : ViewModel() {
    val products = repository.products

    private val _cart = MutableStateFlow<Map<Long, Double>>(emptyMap())
    val cart: StateFlow<Map<Long, Double>> = _cart.asStateFlow()

    fun entries(): List<PurchaseEntry> {
        val byId = products.value.associateBy { it.id }
        return _cart.value.mapNotNull { (id, qty) ->
            byId[id]?.let { PurchaseEntry(it, qty) }
        }
    }

    fun addToCart(id: Long) {
        val product = products.value.firstOrNull { it.id == id } ?: return
        val suggested = max(1.0, product.minStock * 2 - product.stock)
        _cart.value = _cart.value + (id to (_cart.value[id] ?: suggested))
        OperationBus.push("\u00AB${product.name}\u00BB добавлен в заявку")
    }

    fun setQty(id: Long, qty: Double) {
        if (qty <= 0) {
            remove(id)
        } else {
            _cart.value = _cart.value + (id to qty)
        }
    }

    fun remove(id: Long) { _cart.value = _cart.value - id }

    fun clear() { _cart.value = emptyMap() }

    fun autofillDeficit() {
        _cart.value = products.value
            .filter { it.status != ProductStatus.OK }
            .associate { it.id to max(1.0, ceil(it.minStock * 2 - it.stock)) }
    }

    fun hasDeficit(): Boolean = products.value.any { it.status != ProductStatus.OK }

    fun totalCount(): Int = _cart.value.size

    /** Проведение прихода: увеличивает остатки и пишет в историю. */
    fun receive(actor: String): Boolean {
        val entries = entries()
        if (entries.isEmpty()) return false
        entries.forEach { entry -> repository.changeStock(entry.product.id, entry.qty) }
        val total = entries.sumOf { it.product.price * it.qty }
        repository.log(
            "Закупка проведена: позиций ${entries.size} на сумму ${total.formatRub()} — $actor",
        )
        _cart.value = emptyMap()
        OperationBus.push("Приход проведён: ${entries.size} позиций")
        return true
    }
}
