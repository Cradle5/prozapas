package ru.prozapas.data

import android.content.SharedPreferences

/** Режим темы: как в системе / фиксированная светлая / фиксированная тёмная. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class SettingsState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val forceDarkContent: Boolean = false,
)

/** Хранилище настроек темы (сохраняется между запусками, лаба 8, задание 3). */
class SettingsStore(private val prefs: SharedPreferences) {
    fun read(): SettingsState {
        val mode = prefs.getString(KEY_MODE, ThemeMode.SYSTEM.name)
            ?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
            ?: ThemeMode.SYSTEM
        return SettingsState(mode, prefs.getBoolean(KEY_FORCE_DARK, false))
    }

    fun write(state: SettingsState) {
        prefs.edit()
            .putString(KEY_MODE, state.themeMode.name)
            .putBoolean(KEY_FORCE_DARK, state.forceDarkContent)
            .apply()
    }

    private companion object {
        const val KEY_MODE = "themeMode"
        const val KEY_FORCE_DARK = "forceDarkContent"
    }
}
