package ru.prozapas.ui.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ru.prozapas.data.SettingsState
import ru.prozapas.data.SettingsStore
import ru.prozapas.data.ThemeMode

/** ViewModel настроек: тема переживает пересоздание экрана и запуск приложения. */
class SettingsViewModel(private val store: SettingsStore) : ViewModel() {
    private val _state = MutableStateFlow(store.read())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        _state.value = _state.value.copy(themeMode = mode)
        store.write(_state.value)
    }

    fun setForceDarkContent(value: Boolean) {
        _state.value = _state.value.copy(forceDarkContent = value)
        store.write(_state.value)
    }
}
