package ru.prozapas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.FormField
import ru.prozapas.theme.HeaderGradientEnd
import ru.prozapas.theme.HeaderGradientStart
import ru.prozapas.ui.viewmodel.AuthViewModel

/**
 * Экран входа и регистрации (лаба 6 «Главная»-подготовка, лаба 8 FormField).
 * Первая учётная запись становится Руководителем.
 */
@Composable
fun AuthScreen(onAuthSuccess: () -> Unit) {
    val viewModel: AuthViewModel = viewModel {
        AuthViewModel(ServiceLocator.container.authRepository)
    }
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    LaunchedEffect(currentUser) {
        if (currentUser != null) onAuthSuccess()
    }

    var isLoginMode by rememberSaveable { mutableStateOf(true) }
    var loginName by rememberSaveable { mutableStateOf("") }
    var loginPw by rememberSaveable { mutableStateOf("") }
    var regName by rememberSaveable { mutableStateOf("") }
    var regLogin by rememberSaveable { mutableStateOf("") }
    var regPw by rememberSaveable { mutableStateOf("") }
    var regPwConfirm by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(HeaderGradientStart, HeaderGradientEnd))),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Прозапас",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                "Управление товарными запасами и закупками",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
            )

            androidx.compose.foundation.layout.Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AppButton(
                    modifier = Modifier.weight(1f),
                    text = "Вход",
                    onClick = { isLoginMode = true; error = null },
                    style = if (isLoginMode) ru.prozapas.ui.components.ButtonStyle.PRIMARY else ru.prozapas.ui.components.ButtonStyle.OUTLINED,
                )
                AppButton(
                    modifier = Modifier.weight(1f),
                    text = "Регистрация",
                    onClick = { isLoginMode = false; error = null },
                    style = if (!isLoginMode) ru.prozapas.ui.components.ButtonStyle.PRIMARY else ru.prozapas.ui.components.ButtonStyle.OUTLINED,
                )
            }

            if (isLoginMode) {
                FormField(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    value = loginName,
                    onValueChange = { loginName = it },
                    label = "Логин",
                )
                FormField(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    value = loginPw,
                    onValueChange = { loginPw = it },
                    label = "Пароль",
                )
            } else {
                FormField(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    value = regName,
                    onValueChange = { regName = it },
                    label = "Фамилия и имя",
                )
                FormField(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    value = regLogin,
                    onValueChange = { regLogin = it },
                    label = "Логин",
                )
                FormField(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    value = regPw,
                    onValueChange = { regPw = it },
                    label = "Пароль (не менее 4 символов)",
                )
                FormField(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    value = regPwConfirm,
                    onValueChange = { regPwConfirm = it },
                    label = "Повторите пароль",
                )
            }

            if (error != null) {
                Text(
                    error!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            AppButton(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                text = if (isLoginMode) "Войти в систему" else "Создать учётную запись",
                onClick = {
                    error = null
                    if (isLoginMode) {
                        viewModel.login(loginName, loginPw) { err -> error = err }
                    } else {
                        viewModel.register(regName, regLogin, regPw, regPwConfirm) { err -> error = err }
                    }
                },
            )

            if (!isLoginMode) {
                Text(
                    "Первая учётная запись получает роль «Руководитель» с полным доступом. Дальнейшие учётки создаёт руководитель в разделе «Пользователи».",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 16.dp),
                )
            }
        }
    }
}
