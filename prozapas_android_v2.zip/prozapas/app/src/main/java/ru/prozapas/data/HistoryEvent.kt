package ru.prozapas.data

import androidx.compose.runtime.Immutable

@Immutable
data class HistoryEvent(
    val id: Long,
    val time: Long,
    val text: String,
)
