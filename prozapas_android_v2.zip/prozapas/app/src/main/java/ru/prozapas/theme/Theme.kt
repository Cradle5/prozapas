package ru.prozapas.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

/**
 * Расширенные цвета вне стандартной схемы Material (лабораторная работа 8, задание 2):
 * цвета статусов остатков и градиент шапки. Доступ через LocalExtendedColors.
 */
@Immutable
data class ExtendedColors(
    val statusOk: Color,
    val statusLow: Color,
    val statusOut: Color,
    val headerGradient: Brush,
)

val LocalExtendedColors = staticCompositionLocalOf {
    ExtendedColors(
        statusOk = StatusOkColor,
        statusLow = StatusLowColor,
        statusOut = StatusOutColor,
        headerGradient = Brush.horizontalGradient(listOf(HeaderGradientStart, HeaderGradientEnd)),
    )
}

object ProZapasColors {
    val ok: Color @Composable get() = LocalExtendedColors.current.statusOk
    val low: Color @Composable get() = LocalExtendedColors.current.statusLow
    val out: Color @Composable get() = LocalExtendedColors.current.statusOut
    val headerGradient: Brush @Composable get() = LocalExtendedColors.current.headerGradient
}

/**
 * Единая тема приложения (лабораторная работа 8, шаг 1 и задание 3):
 * - кастомные схемы LightColors / DarkColors с фиолетовым primary;
 * - динамические цвета Android 12+;
 * - forceDarkContent — принудительно тёмная схема контента даже в светлой теме.
 */
@Composable
fun AppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    forceDarkContent: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colorScheme = when {
        forceDarkContent -> DarkColors
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }
    val extended = ExtendedColors(
        statusOk = StatusOkColor,
        statusLow = StatusLowColor,
        statusOut = StatusOutColor,
        headerGradient = Brush.horizontalGradient(listOf(HeaderGradientStart, HeaderGradientEnd)),
    )
    CompositionLocalProvider(LocalExtendedColors provides extended) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content,
        )
    }
}
