package ru.prozapas.data

import androidx.compose.runtime.Immutable

enum class ProductStatus { OK, LOW, OUT }

/**
 * Товар на складе. @Immutable подтверждает для компилятора Compose,
 * что экземпляр не меняется in-place (лабораторная работа 9, модуль 5).
 */
@Immutable
data class Product(
    val id: Long,
    val name: String,
    val sku: String,
    val category: String,
    val unit: String,
    val price: Double,
    val stock: Double,
    val minStock: Double,
    val supplier: String,
) {
    val status: ProductStatus
        get() = when {
            stock <= 0 -> ProductStatus.OUT
            stock < minStock -> ProductStatus.LOW
            else -> ProductStatus.OK
        }

    fun withStock(newStock: Double) = copy(stock = newStock.coerceAtLeast(0.0))
}
