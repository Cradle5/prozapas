package ru.prozapas.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import ru.prozapas.data.Role
import ru.prozapas.data.User
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.FormField
import ru.prozapas.ui.components.ProZapasHeader

/** Раздел «Пользователи»: смена роли, сброс пароля, удаление, создание учёток. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersScreen(navController: NavController) {
    val viewModel: ru.prozapas.ui.viewmodel.UsersViewModel = viewModel {
        ru.prozapas.ui.viewmodel.UsersViewModel(ServiceLocator.container.authRepository)
    }
    val users by viewModel.users.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    var showAdd by remember { mutableStateOf(false) }
    var resetTarget by remember { mutableStateOf<User?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            ProZapasHeader(
                title = "Пользователи",
                subtitle = "Учётные записи и роли",
                actions = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
            )
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(users, key = { it.id }) { user ->
                    UserRow(
                        user = user,
                        isMe = user.id == currentUser?.id,
                        onRoleChange = { role -> viewModel.setRole(user.id, role) },
                        onResetPw = { resetTarget = user },
                        onDelete = { viewModel.deleteUser(user.id) },
                    )
                    HorizontalDivider()
                }
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AppButton(
                            modifier = Modifier.fillMaxWidth(),
                            text = "\uFF0B Создать учётную запись",
                            onClick = { showAdd = true },
                            style = ButtonStyle.PRIMARY,
                        )
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddUserDialog(
            onDismiss = { showAdd = false },
            onCreate = { name, login, pw, role ->
                var error: String? = null
                viewModel.addAccount(name, login, pw, role) { err -> error = err }
                error
            },
        )
    }

    resetTarget?.let { target ->
        ResetPasswordDialog(
            userName = target.name,
            onDismiss = { resetTarget = null },
            onReset = { pw ->
                if (viewModel.resetPassword(target.id, pw)) {
                    resetTarget = null
                }
            },
        )
    }
}

@Composable
private fun UserRow(
    user: User,
    isMe: Boolean,
    onRoleChange: (Role) -> Unit,
    onResetPw: () -> Unit,
    onDelete: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                if (isMe) "${user.name} (вы)" else user.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                user.login,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Box {
            var menuOpen by remember { mutableStateOf(false) }
            var roleName by remember { mutableStateOf(user.role.label) }
            androidx.compose.material3.FilledTonalButton(onClick = { menuOpen = true }) {
                Text(roleName)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                Role.entries.forEach { role ->
                    DropdownMenuItem(
                        text = { Text(role.label) },
                        onClick = {
                            roleName = role.label
                            onRoleChange(role)
                            menuOpen = false
                        },
                    )
                }
            }
        }
        IconButton(onClick = onResetPw) {
            Icon(Icons.Default.Lock, contentDescription = "Сбросить пароль")
        }
        IconButton(onClick = onDelete, enabled = !isMe) {
            Icon(Icons.Default.Delete, contentDescription = "Удалить учётную запись")
        }
    }
}

@Composable
private fun AddUserDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String, String, Role) -> String?,
) {
    var name by remember { mutableStateOf("") }
    var login by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(Role.TOVAR) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая учётная запись") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FormField(value = name, onValueChange = { name = it }, label = "Фамилия и имя")
                FormField(value = login, onValueChange = { login = it }, label = "Логин")
                FormField(value = pw, onValueChange = { pw = it }, label = "Пароль (не менее 4 символов)")
                Text("Роль", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Role.entries.forEach { r ->
                        FilterChip(
                            selected = role == r,
                            onClick = { role = r },
                            label = { Text(r.label) },
                        )
                    }
                }
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            AppButton(
                text = "Создать",
                onClick = {
                    val err = onCreate(name, login, pw, role)
                    if (err == null) {
                        onDismiss()
                    } else {
                        error = err
                    }
                },
                style = ButtonStyle.PRIMARY,
            )
        },
        dismissButton = {
            AppButton(text = "Отмена", onClick = onDismiss, style = ButtonStyle.OUTLINED)
        },
    )
}

@Composable
private fun ResetPasswordDialog(
    userName: String,
    onDismiss: () -> Unit,
    onReset: (String) -> Unit,
) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Сброс пароля") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Новый пароль для пользователя «$userName»", style = MaterialTheme.typography.bodySmall)
                FormField(value = pw, onValueChange = { pw = it }, label = "Новый пароль")
            }
        },
        confirmButton = {
            AppButton(
                text = "Сбросить",
                onClick = { onReset(pw) },
                style = ButtonStyle.PRIMARY,
            )
        },
        dismissButton = {
            AppButton(text = "Отмена", onClick = onDismiss, style = ButtonStyle.OUTLINED)
        },
    )
}
