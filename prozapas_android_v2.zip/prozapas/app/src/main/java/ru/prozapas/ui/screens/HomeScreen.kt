package ru.prozapas.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import ru.prozapas.data.Role
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.ButtonSize
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.ProZapasHeader

/** «Главная» (лабораторная работа 6, задание 1). */
@Composable
fun HomeScreen(navController: NavController) {
    val currentUser by ServiceLocator.container.authRepository.currentUser.collectAsStateWithLifecycle()
    val role = currentUser?.role ?: Role.TOVAR

    Column(modifier = Modifier.fillMaxSize()) {
        ProZapasHeader(
            title = "Прозапас",
            subtitle = "Управление товарными запасами и закупками",
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                "Добро пожаловать, ${currentUser?.name.orEmpty()}!",
                style = MaterialTheme.typography.headlineMedium,
            )
            Text(
                "Система учёта остатков на складе и заявок на закупку.\nВаша роль: ${role.label}.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Перейти к складу",
                onClick = { navController.navigate("stock") },
                style = ButtonStyle.PRIMARY,
                size = ButtonSize.LARGE,
            )
            if (role.canPurchase) {
                AppButton(
                    modifier = Modifier.fillMaxWidth(),
                    text = "Заявки на закупку",
                    onClick = { navController.navigate("purchase") },
                    style = ButtonStyle.SECONDARY,
                    size = ButtonSize.LARGE,
                )
            }
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Мой профиль",
                onClick = { navController.navigate("profile") },
                style = ButtonStyle.SECONDARY,
                size = ButtonSize.MEDIUM,
            )
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Настройки",
                onClick = { navController.navigate("settings") },
                style = ButtonStyle.OUTLINED,
                size = ButtonSize.MEDIUM,
            )
            if (role.canManageUsers) {
                AppButton(
                    modifier = Modifier.fillMaxWidth(),
                    text = "Пользователи и роли",
                    onClick = { navController.navigate("users") },
                    style = ButtonStyle.OUTLINED,
                    size = ButtonSize.MEDIUM,
                )
            }
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Каталог постов (демо API)",
                onClick = { navController.navigate("posts") },
                style = ButtonStyle.OUTLINED,
                size = ButtonSize.MEDIUM,
            )
        }
    }
}
