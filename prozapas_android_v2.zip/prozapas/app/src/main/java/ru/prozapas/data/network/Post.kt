package ru.prozapas.data.network

import com.google.gson.annotations.SerializedName

/** Модель поста публичного API jsonplaceholder.typicode.com. */
data class Post(
    @SerializedName("id") val id: Int,
    @SerializedName("userId") val userId: Int,
    @SerializedName("title") val title: String,
    @SerializedName("body") val body: String,
)

data class Comment(
    @SerializedName("id") val id: Int,
    @SerializedName("postId") val postId: Int,
    @SerializedName("name") val name: String,
    @SerializedName("email") val email: String,
    @SerializedName("body") val body: String,
)
