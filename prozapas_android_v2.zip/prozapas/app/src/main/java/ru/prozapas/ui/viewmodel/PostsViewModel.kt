package ru.prozapas.ui.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ru.prozapas.data.network.ApiError
import ru.prozapas.data.network.Comment
import ru.prozapas.data.network.Post
import ru.prozapas.data.network.PostsRepository

/** Состояния экрана списка постов: Loading / Success / Error (лаба 10). */
sealed interface PostsUiState {
    data object Loading : PostsUiState
    data class Success(
        val posts: List<Post>,
        val isRefreshing: Boolean,
        val endReached: Boolean,
    ) : PostsUiState
    data class Error(val message: String) : PostsUiState
}

/** ViewModel «Каталога постов»: пагинация по 20, обновление, повтор. */
class PostsViewModel(private val repository: PostsRepository) : ViewModel() {
    private val _state = MutableStateFlow<PostsUiState>(PostsUiState.Loading)
    val state: StateFlow<PostsUiState> = _state.asStateFlow()

    private val loaded = mutableListOf<Post>()
    private var page = 0
    private var endReached = false
    private var isRequestActive = false

    init {
        loadFirst()
    }

    fun loadFirst() {
        if (isRequestActive) return
        isRequestActive = true
        _state.value = PostsUiState.Loading
        fetchPage(reset = true)
    }

    fun refresh() {
        if (isRequestActive) return
        val current = _state.value
        if (current !is PostsUiState.Success) {
            loadFirst()
            return
        }
        isRequestActive = true
        _state.value = current.copy(isRefreshing = true)
        fetchPage(reset = true)
    }

    fun loadMore() {
        if (isRequestActive || endReached) return
        val current = _state.value
        if (current !is PostsUiState.Success) return
        isRequestActive = true
        fetchPage(reset = false)
    }

    private fun fetchPage(reset: Boolean) {
        val pageToLoad = if (reset) 0 else page
        viewModelScope.launch {
            repository.getPosts(page = pageToLoad).fold(
                onSuccess = { posts ->
                    isRequestActive = false
                    if (reset) {
                        loaded.clear()
                        loaded.addAll(posts)
                        page = 1
                    } else {
                        loaded.addAll(posts)
                        page += 1
                    }
                    endReached = posts.size < 20
                    _state.value = PostsUiState.Success(loaded.toList(), isRefreshing = false, endReached = endReached)
                },
                onFailure = { error ->
                    isRequestActive = false
                    if (reset && loaded.isEmpty()) {
                        _state.value = PostsUiState.Error(
                            (error as? ApiError)?.userMessage() ?: (error.message ?: "Неизвестная ошибка"),
                        )
                    } else {
                        endReached = true
                        _state.value = PostsUiState.Success(loaded.toList(), isRefreshing = false, endReached = true)
                    }
                },
            )
        }
    }
}

/** Состояние детального экрана поста. */
sealed interface PostDetailUiState {
    data object Loading : PostDetailUiState
    data class Success(val post: Post, val comments: List<Comment>) : PostDetailUiState
    data class Error(val message: String) : PostDetailUiState
}

/** ViewModel деталей: id выживает смерть процесса через SavedStateHandle (лаба 10). */
class PostDetailViewModel(
    savedStateHandle: SavedStateHandle,
    private val repository: PostsRepository,
) : ViewModel() {
    private val postId: Int = checkNotNull(savedStateHandle["postId"])

    private val _state = MutableStateFlow<PostDetailUiState>(PostDetailUiState.Loading)
    val state: StateFlow<PostDetailUiState> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        if (_state.value is PostDetailUiState.Loading) {
            viewModelScope.launch {
                repository.getPost(postId).fold(
                    onSuccess = { post ->
                        repository.getComments(postId).fold(
                            onSuccess = { comments -> _state.value = PostDetailUiState.Success(post, comments) },
                            onFailure = { _state.value = PostDetailUiState.Success(post, emptyList()) },
                        )
                    },
                    onFailure = { error ->
                        _state.value = PostDetailUiState.Error(
                            (error as? ApiError)?.userMessage() ?: (error.message ?: "Неизвестная ошибка"),
                        )
                    },
                )
            }
        }
    }
}
