package ru.prozapas.ui.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Стили кнопки: заполненная, тональная, с обводкой (лабораторная работа 8). */
enum class ButtonStyle { PRIMARY, SECONDARY, OUTLINED }

/** Размеры кнопки через contentPadding и размер шрифта. */
enum class ButtonSize { SMALL, MEDIUM, LARGE }

/**
 * Переиспользуемая кнопка приложения. Цвета берутся из MaterialTheme.colorScheme,
 * без хардкода. Первый параметр — modifier.
 */
@Composable
fun AppButton(
    modifier: Modifier = Modifier,
    text: String,
    style: ButtonStyle = ButtonStyle.PRIMARY,
    size: ButtonSize = ButtonSize.MEDIUM,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val contentPadding = when (size) {
        ButtonSize.SMALL -> PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ButtonSize.MEDIUM -> PaddingValues(horizontal = 18.dp, vertical = 10.dp)
        ButtonSize.LARGE -> PaddingValues(horizontal = 26.dp, vertical = 14.dp)
    }
    val fontSize = when (size) {
        ButtonSize.SMALL -> 12.sp
        ButtonSize.MEDIUM -> 14.sp
        ButtonSize.LARGE -> 17.sp
    }
    when (style) {
        ButtonStyle.PRIMARY -> Button(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier,
            contentPadding = contentPadding,
        ) { Text(text, fontSize = fontSize) }
        ButtonStyle.SECONDARY -> FilledTonalButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier,
            contentPadding = contentPadding,
        ) { Text(text, fontSize = fontSize) }
        ButtonStyle.OUTLINED -> OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier,
            contentPadding = contentPadding,
        ) { Text(text, fontSize = fontSize) }
    }
}
