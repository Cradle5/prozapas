package ru.prozapas.ui.util

import java.text.NumberFormat
import java.util.Locale

private val moneyFormat: NumberFormat = NumberFormat.getNumberInstance(
    Locale("ru", "RU"),
).apply { maximumFractionDigits = 2; minimumFractionDigits = 0 }

private val qtyFormat: NumberFormat = NumberFormat.getNumberInstance(
    Locale("ru", "RU"),
).apply { maximumFractionDigits = 2; minimumFractionDigits = 0 }

fun Double.formatRub(): String = moneyFormat.format(this) + " \u20BD"
fun Double.formatQty(): String = qtyFormat.format(this)
