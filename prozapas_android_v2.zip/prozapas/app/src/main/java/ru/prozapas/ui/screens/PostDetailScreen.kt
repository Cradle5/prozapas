package ru.prozapas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.ProZapasHeader
import ru.prozapas.ui.viewmodel.PostDetailUiState
import ru.prozapas.ui.viewmodel.PostDetailViewModel

/** Детальный экран поста: пост + комментарии (лабораторная работа 10). */
@Composable
fun PostDetailScreen(
    savedStateHandle: SavedStateHandle,
    onBack: () -> Unit,
) {
    val viewModel: PostDetailViewModel = viewModel(key = null) {
        PostDetailViewModel(savedStateHandle, ServiceLocator.container.postsRepository)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            ProZapasHeader(
                title = "Пост",
                actions = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
            )
            when (val s = state) {
                PostDetailUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is PostDetailUiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(s.message, textAlign = TextAlign.Center)
                            Button(onClick = onBack, modifier = Modifier.padding(top = 12.dp)) {
                                Text("Вернуться к списку")
                            }
                        }
                    }
                }
                is PostDetailUiState.Success -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        AsyncImage(
                            model = "https://picsum.photos/seed/post${s.post.id}/600/240",
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                        )
                        Text("Пост \u2116 ${s.post.id}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(s.post.title, style = MaterialTheme.typography.headlineMedium)
                        Text(s.post.body, style = MaterialTheme.typography.bodyLarge)
                        Text("Комментарии (${s.comments.size})", style = MaterialTheme.typography.titleLarge)
                        s.comments.forEach { comment ->
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(comment.name, style = MaterialTheme.typography.labelLarge)
                                Text(comment.body, style = MaterialTheme.typography.bodySmall)
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }
    }
}
