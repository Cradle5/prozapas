package ru.prozapas.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.error
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription

/** Состояния поля ввода (лабораторная работа 8, задание 3). */
enum class FormFieldState { IDLE, ERROR, WARNING, DISABLED }

/**
 * Кастомное поле ввода с визуально и семантически различимыми состояниями:
 * ERROR — красная рамка и текст ошибки, WARNING — жёлтая, DISABLED — недоступно.
 */
@Composable
fun FormField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    state: FormFieldState = FormFieldState.IDLE,
    modifier: Modifier = Modifier,
    supportingTextOverride: String? = null,
    contentDescriptionOverride: String? = null,
) {
    val colors = when (state) {
        FormFieldState.IDLE -> OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
        )
        FormFieldState.ERROR -> OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.error,
            unfocusedBorderColor = MaterialTheme.colorScheme.error,
        )
        FormFieldState.WARNING -> OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFF59E0B),
            unfocusedBorderColor = Color(0xFFF59E0B),
        )
        FormFieldState.DISABLED -> OutlinedTextFieldDefaults.colors(
            disabledBorderColor = MaterialTheme.colorScheme.outline,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
    val supporting: @Composable (() -> Unit)? = when {
        supportingTextOverride != null -> ({ Text(supportingTextOverride) })
        state == FormFieldState.ERROR -> ({ Text("Проверьте значение") })
        state == FormFieldState.DISABLED -> null
        else -> null
    }
    val semanticsModifier = when (state) {
        FormFieldState.DISABLED -> modifier.semantics { stateDescription = "Недоступно" }
        FormFieldState.ERROR -> modifier.semantics { error("Проверьте значение") }
        else -> modifier
    }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        enabled = state != FormFieldState.DISABLED,
        isError = state == FormFieldState.ERROR,
        singleLine = true,
        supportingText = supporting,
        colors = colors,
        modifier = semanticsModifier,
    )
}
