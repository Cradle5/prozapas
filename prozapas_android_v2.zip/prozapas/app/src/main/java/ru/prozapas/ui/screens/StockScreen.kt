package ru.prozapas.ui.screens

import android.util.Log
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.prozapas.data.OperationBus
import ru.prozapas.data.Product
import ru.prozapas.data.ProductStatus
import ru.prozapas.data.Role
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.ButtonSize
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.ProZapasHeader
import ru.prozapas.ui.components.PulsingDots
import ru.prozapas.ui.components.SnackbarLikeMessage
import ru.prozapas.theme.ProZapasColors
import ru.prozapas.ui.util.formatQty
import ru.prozapas.ui.util.formatRub
import ru.prozapas.ui.viewmodel.PurchaseViewModel
import ru.prozapas.ui.viewmodel.StockUiState
import ru.prozapas.ui.viewmodel.StockViewModel

/** Теги для instrumented-тестов (лабораторная работа 9, модуль 3). */
object StockTestTags {
    const val SEARCH_FIELD = "searchField"
    const val LOAD_MORE = "loadMore"
    const val REFRESH_BUTTON = "refreshButton"

    fun productRow(id: Long) = "productRow_$id"
}

/**
 * Экран «Склад»: LazyColumn с пагинацией (лаба 5), состояния Loading/Success/
 * Refreshing/Error (лаба 7), анимации и побочные эффекты (лаба 9).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockScreen(navController: NavController) {
    val viewModel: StockViewModel = viewModel {
        StockViewModel(ServiceLocator.container.warehouseRepository).also { vm ->
            val user = ServiceLocator.container.authRepository.currentUser.value
            vm.actorRoleCanEditStock = user?.role?.canEditStock ?: false
            vm.actorRoleCanViewPrices = user?.role?.canViewPrices ?: false
            vm.actorRoleCanPurchase = user?.role?.canPurchase ?: false
            vm.actorRoleCanManageUsers = user?.role?.canManageUsers ?: false
        }
    }

    val currentUser by ServiceLocator.container.authRepository.currentUser.collectAsStateWithLifecycle()
    val role = currentUser?.role ?: Role.TOVAR
    val uiState by viewModel.state.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val category by viewModel.category.collectAsStateWithLifecycle()
    val lowOnly by viewModel.lowOnly.collectAsStateWithLifecycle()

    // Первичная загрузка — ровно один вызов на вход в композицию (лаба 9, модуль 2).
    LaunchedEffect(Unit) {
        viewModel.load()
    }

    // Дебаунс поиска 300 мс: запрос «на сервер» отменяется при новом вводе (лаба 9).
    LaunchedEffect(query) {
        if (query.isNotBlank()) {
            delay(300)
            viewModel.searchRemote(query)
        }
    }

    // DisposableEffect: подписка на шину операций с корректной отпиской (лаба 9).
    var busMessage by remember { mutableStateOf<String?>(null) }
    val busListener = remember { { message: String -> busMessage = message } }
    DisposableEffect(Unit) {
        OperationBus.subscribe(busListener)
        onDispose { OperationBus.unsubscribe(busListener) }
    }
    LaunchedEffect(busMessage) {
        if (busMessage != null) {
            delay(2500)
            busMessage = null
        }
    }

    // SideEffect: аналитика «экран показан с фильтром X» без дублей (лаба 9).
    var lastLoggedQuery by remember { mutableStateOf("\u0000") }
    SideEffect {
        if (query != lastLoggedQuery) {
            lastLoggedQuery = query
            Log.d("PROZAPAS_ANALYTICS", "Экран склада, фильтр: \"$query\"")
        }
    }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Общая ViewModel корзины: «В заявку» со склада и заявки делят одну корзину.
    val purchaseViewModel: PurchaseViewModel = viewModel {
        PurchaseViewModel(ServiceLocator.container.warehouseRepository)
    }
    val onAddToCart: (Long) -> Unit = remember(purchaseViewModel) {
        { id -> purchaseViewModel.addToCart(id) }
    }

    // derivedStateOf: кнопка «наверх» появляется один раз при пересечении 5-го элемента (лаба 9).
    val showTopButton by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 5 }
    }

    // derivedStateOf: фильтрация пересчитывается только при изменении входов (лаба 9, модуль 5).
    val categories = products.map { it.category }.distinct()
    val filtered by remember {
        derivedStateOf {
            products
                .filter { product ->
                    (category.isEmpty() || product.category == category) &&
                        (!lowOnly || product.status != ProductStatus.OK) &&
                        (query.isBlank() ||
                            (product.name + " " + product.sku + " " + product.supplier)
                                .contains(query, ignoreCase = true))
                }
                .sortedWith(compareBy({ statusOrder(it.status) }, { it.id }))
        }
    }

    when (val state = uiState) {
        StockUiState.Loading -> LoadingState()
        is StockUiState.Error -> ErrorState(error = state, onRetry = viewModel::retry)
        is StockUiState.Success -> StockContent(
            navController = navController,
            viewModel = viewModel,
            products = products,
            filtered = filtered,
            visibleCount = state.visibleCount,
            cachedAt = state.cachedAt,
            query = query,
            category = category,
            lowOnly = lowOnly,
            categories = categories,
            listState = listState,
            showTopButton = showTopButton,
            scope = scope,
            busMessage = busMessage,
            role = role,
            onAddToCart = onAddToCart,
        )
        is StockUiState.Refreshing -> StockContent(
            navController = navController,
            viewModel = viewModel,
            products = products,
            filtered = filtered,
            visibleCount = state.visibleCount,
            cachedAt = state.cachedAt,
            query = query,
            category = category,
            lowOnly = lowOnly,
            categories = categories,
            listState = listState,
            showTopButton = showTopButton,
            scope = scope,
            busMessage = busMessage,
            role = role,
            onAddToCart = onAddToCart,
            isRefreshing = true,
        )
    }
}

private fun statusOrder(status: ProductStatus): Int = when (status) {
    ProductStatus.OUT -> 0
    ProductStatus.LOW -> 1
    ProductStatus.OK -> 2
}

private fun statusLabel(status: ProductStatus): String = when (status) {
    ProductStatus.OUT -> "Нет в наличии"
    ProductStatus.LOW -> "Мало"
    ProductStatus.OK -> "В норме"
}

@Composable
private fun LoadingState(message: String = "Загрузка данных…") {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Text(message, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

@Composable
private fun ErrorState(error: StockUiState.Error, onRetry: () -> Unit) {
    val icon = if (error.message.contains("сервер", ignoreCase = true)) {
        Icons.Default.CloudOff
    } else {
        Icons.Default.WifiOff
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp),
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(56.dp),
            )
            Text(
                error.message,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(vertical = 12.dp),
            )
            if (error.retryCount > 1) {
                Text(
                    "Повторить можно через ${error.retryDelayMs / 1000} с",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            AppButton(text = "Повторить", onClick = onRetry, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StockContent(
    navController: NavController,
    viewModel: StockViewModel,
    products: List<Product>,
    filtered: List<Product>,
    visibleCount: Int,
    cachedAt: Long,
    query: String,
    category: String,
    lowOnly: Boolean,
    categories: List<String>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    showTopButton: Boolean,
    scope: kotlinx.coroutines.CoroutineScope,
    busMessage: String?,
    role: Role,
    onAddToCart: (Long) -> Unit,
    isRefreshing: Boolean = false,
) {
    val actorName = ServiceLocator.container.authRepository.currentUser.value?.name ?: "—"
    val visible = filtered.take(visibleCount)
    val hasMore = filtered.size > visibleCount

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        floatingActionButton = {
            if (showTopButton) {
                FloatingActionButton(onClick = { scope.launch { listState.animateScrollToItem(0) } }) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = "Наверх")
                }
            }
        },
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            ProZapasHeader(
                title = "Склад",
                subtitle = "Остатки и статусы позиций",
                actions = {
                    IconButton(
                        onClick = { viewModel.refresh() },
                        modifier = Modifier.testTag(StockTestTags.REFRESH_BUTTON),
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Обновить данные")
                    }
                    IconButton(onClick = { navController.navigate("profile") }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Профиль")
                    }
                },
            )
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                SnackbarLikeMessage(message = busMessage)
                OutlinedTextField(
                    value = query,
                    onValueChange = viewModel::onQueryChange,
                    label = { Text("Поиск: название, артикул, поставщик") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(StockTestTags.SEARCH_FIELD),
                )
                androidx.compose.foundation.lazy.LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        FilterChip(
                            selected = category.isEmpty(),
                            onClick = { viewModel.setCategory("") },
                            label = { Text("Все") },
                        )
                    }
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { viewModel.setCategory(cat) },
                            label = { Text(cat) },
                        )
                    }
                    item {
                        FilterChip(
                            selected = lowOnly,
                            onClick = { viewModel.setLowOnly(!lowOnly) },
                            label = { Text("Только дефицит") },
                        )
                    }
                }
                Text(
                    "Показано: ${visible.size} из ${filtered.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    items(visible, key = { it.id }) { product ->
                        ProductRow(
                            product = product,
                            canEditStock = role.canEditStock,
                            canViewPrices = role.canViewPrices,
                            canPurchase = role.canPurchase,
                            canDelete = role.canManageUsers,
                            onOpen = { navController.navigate("product/${product.id}") },
                            onAddToCart = onAddToCart,
                            onDelete = { id -> viewModel.deleteProduct(id, actorName) },
                            onChangeStock = { id, delta -> viewModel.changeStock(id, delta, actorName) },
                        )
                        HorizontalDivider()
                    }
                    if (filtered.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier.fillParentMaxSize(),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    "Ничего не найдено",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            if (hasMore) {
                                Button(
                                    onClick = { viewModel.loadMore() },
                                    modifier = Modifier.testTag(StockTestTags.LOAD_MORE),
                                ) {
                                    Text("Загрузить ещё")
                                }
                            } else if (filtered.isNotEmpty()) {
                                Text(
                                    "Больше нет данных",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
                if (isRefreshing) {
                    // Полупрозрачный оверлей обновления поверх списка (лаба 7, задание 2).
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            PulsingDots()
                            Text("Обновление…", modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductRow(
    product: Product,
    canEditStock: Boolean,
    canViewPrices: Boolean,
    canPurchase: Boolean,
    canDelete: Boolean,
    onOpen: () -> Unit,
    onAddToCart: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onChangeStock: (Long, Double) -> Unit,
) {
    // Локальное UI-состояние строки (лаба 4): нормально не поднимать наверх.
    var expanded by remember { mutableStateOf(false) }

    val statusColor = when (product.status) {
        ProductStatus.OK -> ProZapasColors.ok
        ProductStatus.LOW -> ProZapasColors.low
        ProductStatus.OUT -> ProZapasColors.out
    }
    // Анимация цвета статуса (лаба 9, модуль 1).
    val animatedStatusColor by animateColorAsState(
        targetValue = statusColor,
        animationSpec = tween(250),
        label = "statusColor",
    )
    val animatedRowBackground by animateColorAsState(
        targetValue = if (product.status == ProductStatus.OUT) {
            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
        } else {
            Color.Transparent
        },
        animationSpec = tween(250),
        label = "rowBackground",
    )
    val animatedPadding by animateDpAsState(
        targetValue = if (product.status == ProductStatus.OUT) 6.dp else 0.dp,
        label = "rowPadding",
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(StockTestTags.productRow(product.id))
            .background(animatedRowBackground)
            .padding(vertical = animatedPadding)
            .animateContentSize()
            .clickable { onOpen() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(32.dp)) {
                Icon(
                    Icons.Default.Info,
                    contentDescription = if (expanded) "Свернуть детали" else "Подробнее",
                    modifier = Modifier.size(18.dp),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    product.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                )
                Text(
                    "${product.sku} · ${product.category}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (canEditStock) {
                        IconButton(onClick = { onChangeStock(product.id, -1.0) }, modifier = Modifier.size(28.dp)) {
                            Icon(
                                Icons.Default.Remove,
                                contentDescription = "Списать 1 ${product.unit}",
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                    Text(
                        "${product.stock.formatQty()} ${product.unit}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    )
                    if (canEditStock) {
                        IconButton(onClick = { onChangeStock(product.id, 1.0) }, modifier = Modifier.size(28.dp)) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Принять 1 ${product.unit}",
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
                Text(
                    statusLabel(product.status),
                    color = animatedStatusColor,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
        // Анимация раскрытия с композитным enter/exit и label (лаба 9, 1.2).
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(tween(150)) + expandVertically(tween(220)),
            exit = fadeOut(tween(100)) + shrinkVertically(tween(180)),
            label = "productDetails",
        ) {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                if (canViewPrices) {
                    Text("Цена: ${product.price.formatRub()}", style = MaterialTheme.typography.bodySmall)
                }
                Text("Минимум: ${product.minStock.formatQty()} ${product.unit}", style = MaterialTheme.typography.bodySmall)
                Text("Поставщик: ${product.supplier}", style = MaterialTheme.typography.bodySmall)
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (canPurchase) {
                        AppButton(
                            text = "В заявку",
                            onClick = { onAddToCart(product.id) },
                            style = ButtonStyle.SECONDARY,
                            size = ButtonSize.SMALL,
                        )
                    }
                    if (canDelete) {
                        AppButton(
                            text = "Удалить",
                            onClick = { onDelete(product.id) },
                            style = ButtonStyle.OUTLINED,
                            size = ButtonSize.SMALL,
                        )
                    }
                }
            }
        }
    }
}
