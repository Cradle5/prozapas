package ru.prozapas.ui.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.StateFlow
import ru.prozapas.data.AuthRepository
import ru.prozapas.data.Role
import ru.prozapas.data.User

/** ViewModel раздела «Пользователи» (только руководитель). */
class UsersViewModel(private val repository: AuthRepository) : ViewModel() {
    val users: StateFlow<List<User>> = repository.users
    val currentUser: StateFlow<User?> = repository.currentUser

    fun addAccount(name: String, login: String, pw: String, role: Role, onResult: (String?) -> Unit) {
        repository.addAccount(name, login, pw, role).fold(
            onSuccess = { onResult(null) },
            onFailure = { onResult(it.message ?: "Ошибка") },
        )
    }

    fun setRole(id: Long, role: Role) = repository.setRole(id, role)

    fun resetPassword(id: Long, pw: String): Boolean = repository.resetPassword(id, pw)

    fun deleteUser(id: Long): Boolean = repository.deleteUser(id)
}
