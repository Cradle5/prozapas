package ru.prozapas.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import ru.prozapas.theme.ProZapasColors

/** Состояния StatusButton (лабораторная работа 8, задание 3). */
enum class ButtonState { IDLE, LOADING, ERROR, SUCCESS }

/**
 * Кнопка с семантически различимыми состояниями. В LOADING/ERROR/SUCCESS
 * кнопка недоступна для клика; семантика описывает состояние для TalkBack.
 */
@Composable
fun StatusButton(
    text: String,
    state: ButtonState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val semanticsModifier = when (state) {
        ButtonState.IDLE -> modifier
        ButtonState.LOADING -> modifier.semantics {
            stateDescription = "Загрузка"
        }
        ButtonState.ERROR -> modifier.semantics {
            stateDescription = "Ошибка"
            contentDescription = "Ошибка: повторите действие"
        }
        ButtonState.SUCCESS -> modifier.semantics {
            stateDescription = "Сохранено"
            contentDescription = "Сохранено"
        }
    }
    when (state) {
        ButtonState.IDLE -> AppButton(
            text = text,
            onClick = onClick,
            modifier = semanticsModifier,
        )
        ButtonState.LOADING -> Button(
            onClick = {},
            enabled = false,
            modifier = semanticsModifier,
        ) {
            CircularProgressIndicator(modifier = Modifier.width(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(text)
        }
        ButtonState.ERROR -> Button(
            onClick = {},
            enabled = false,
            modifier = semanticsModifier,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error,
                contentColor = MaterialTheme.colorScheme.onError,
            ),
        ) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(text)
        }
        ButtonState.SUCCESS -> Button(
            onClick = {},
            enabled = false,
            modifier = semanticsModifier,
            colors = ButtonDefaults.buttonColors(
                containerColor = ProZapasColors.ok,
                contentColor = androidx.compose.ui.graphics.Color.White,
            ),
        ) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(text)
        }
    }
}
