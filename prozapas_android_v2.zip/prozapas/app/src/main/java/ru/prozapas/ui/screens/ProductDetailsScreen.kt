package ru.prozapas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import ru.prozapas.data.OperationBus
import ru.prozapas.data.Product
import ru.prozapas.data.ProductStatus
import ru.prozapas.data.Role
import ru.prozapas.di.ServiceLocator
import ru.prozapas.theme.HeaderGradientEnd
import ru.prozapas.theme.HeaderGradientStart
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.ButtonSize
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.FormField
import ru.prozapas.ui.components.SnackbarLikeMessage
import ru.prozapas.ui.util.formatQty
import ru.prozapas.ui.util.formatRub
import ru.prozapas.ui.viewmodel.PurchaseViewModel
import ru.prozapas.ui.viewmodel.StockViewModel

/**
 * Экран «Детали товара» (лабораторная работа 6): данные по переданному ID,
 * обработка «не найден», возврат и очистка состояния. Поддерживает deep link
 * app://myapp/product/{id} (лаба 6, задание 2).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailsScreen(navController: NavController, productId: Long) {
    val viewModel: StockViewModel = viewModel {
        StockViewModel(ServiceLocator.container.warehouseRepository).also { vm ->
            val user = ServiceLocator.container.authRepository.currentUser.value
            vm.actorRoleCanEditStock = user?.role?.canEditStock ?: false
            vm.actorRoleCanViewPrices = user?.role?.canViewPrices ?: false
            vm.actorRoleCanPurchase = user?.role?.canPurchase ?: false
            vm.actorRoleCanManageUsers = user?.role?.canManageUsers ?: false
        }
    }
    val purchaseViewModel: PurchaseViewModel = viewModel {
        PurchaseViewModel(ServiceLocator.container.warehouseRepository)
    }
    val products by viewModel.products.collectAsStateWithLifecycle()
    val currentUser by ServiceLocator.container.authRepository.currentUser.collectAsStateWithLifecycle()
    val role = currentUser?.role ?: Role.TOVAR

    LaunchedEffect(Unit) {
        if (products.isEmpty()) viewModel.load()
    }

    val product = products.firstOrNull { it.id == productId }

    if (product == null) {
        // Обработка «элемент не найден» с понятным UI и возвратом (лаба 6).
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Товар не найден", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Возможно, он был удалён из базы",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp),
            )
            AppButton(
                text = "Вернуться к списку",
                onClick = { navController.popBackStack() },
                modifier = Modifier.padding(top = 16.dp),
            )
        }
        return
    }

    var showEdit by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(message) {
        if (message != null) {
            delay(2200)
            message = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(HeaderGradientStart, HeaderGradientEnd))),
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                }
            }
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(product.name, style = MaterialTheme.typography.headlineMedium)
                Text(
                    "${product.sku} · ${product.category}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                SnackbarLikeMessage(message)
                if (role.canViewPrices) {
                    InfoRow("Цена закупки", product.price.formatRub())
                }
                InfoRow("Поставщик", product.supplier)
                InfoRow("Единица измерения", product.unit)
                InfoRow("Минимальный остаток", "${product.minStock.formatQty()} ${product.unit}")
                InfoRow("Остаток", "${product.stock.formatQty()} ${product.unit}")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.small)
                        .background(
                            when (product.status) {
                                ProductStatus.OK -> ru.prozapas.theme.StatusOkColor.copy(alpha = 0.15f)
                                ProductStatus.LOW -> ru.prozapas.theme.StatusLowColor.copy(alpha = 0.15f)
                                ProductStatus.OUT -> ru.prozapas.theme.StatusOutColor.copy(alpha = 0.15f)
                            },
                        )
                        .padding(10.dp),
                ) {
                    Text(
                        when (product.status) {
                            ProductStatus.OK -> "Статус: в норме"
                            ProductStatus.LOW -> "Статус: ниже минимума"
                            ProductStatus.OUT -> "Статус: нет в наличии"
                        },
                        color = when (product.status) {
                            ProductStatus.OK -> ru.prozapas.theme.StatusOkColor
                            ProductStatus.LOW -> ru.prozapas.theme.StatusLowColor
                            ProductStatus.OUT -> ru.prozapas.theme.StatusOutColor
                        },
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
                if (role.canEditStock) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppButton(
                            text = "Списать 1",
                            onClick = {
                                viewModel.changeStock(product.id, -1.0, currentUser?.name ?: "—")
                                message = "Списано 1 ${product.unit}"
                            },
                            style = ButtonStyle.SECONDARY,
                            size = ButtonSize.SMALL,
                        )
                        AppButton(
                            text = "Принять 1",
                            onClick = {
                                viewModel.changeStock(product.id, 1.0, currentUser?.name ?: "—")
                                message = "Принято 1 ${product.unit}"
                            },
                            style = ButtonStyle.PRIMARY,
                            size = ButtonSize.SMALL,
                        )
                    }
                }
                if (role.canPurchase) {
                    AppButton(
                        modifier = Modifier.fillMaxWidth(),
                        text = "В заявку на закупку",
                        onClick = {
                            purchaseViewModel.addToCart(product.id)
                            message = "Добавлено в заявку на закупку"
                        },
                        style = ButtonStyle.PRIMARY,
                        size = ButtonSize.MEDIUM,
                    )
                }
                if (role.canEditStock) {
                    AppButton(
                        modifier = Modifier.fillMaxWidth(),
                        text = "Редактировать",
                        onClick = { showEdit = true },
                        style = ButtonStyle.SECONDARY,
                        size = ButtonSize.MEDIUM,
                    )
                }
                if (role.canManageUsers) {
                    AppButton(
                        modifier = Modifier.fillMaxWidth(),
                        text = "Удалить товар",
                        onClick = {
                            viewModel.deleteProduct(product.id, currentUser?.name ?: "—")
                            navController.popBackStack()
                        },
                        style = ButtonStyle.OUTLINED,
                        size = ButtonSize.MEDIUM,
                    )
                }
            }
        }
    }

    if (showEdit) {
        EditProductDialog(
            product = product,
            canViewPrices = role.canViewPrices,
            onDismiss = { showEdit = false },
            onSave = { updated ->
                viewModel.upsert(updated, currentUser?.name ?: "—")
                showEdit = false
                message = "Изменения сохранены"
            },
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Text(value, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.End)
    }
}

@Composable
private fun EditProductDialog(
    product: Product,
    canViewPrices: Boolean,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit,
) {
    var name by remember { mutableStateOf(product.name) }
    var category by remember { mutableStateOf(product.category) }
    var supplier by remember { mutableStateOf(product.supplier) }
    var unit by remember { mutableStateOf(product.unit) }
    var minStock by remember { mutableStateOf(product.minStock.toString()) }
    var price by remember { mutableStateOf(product.price.toString()) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактирование товара") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FormField(value = name, onValueChange = { name = it }, label = "Название")
                FormField(value = category, onValueChange = { category = it }, label = "Категория")
                FormField(value = supplier, onValueChange = { supplier = it }, label = "Поставщик")
                FormField(value = unit, onValueChange = { unit = it }, label = "Единица измерения")
                FormField(
                    value = minStock,
                    onValueChange = { minStock = it },
                    label = "Минимальный остаток",
                )
                if (canViewPrices) {
                    FormField(value = price, onValueChange = { price = it }, label = "Цена закупки")
                }
            }
        },
        confirmButton = {
            AppButton(
                text = "Сохранить",
                onClick = {
                    onSave(
                        product.copy(
                            name = name.ifBlank { product.name },
                            category = category.ifBlank { product.category },
                            supplier = supplier.ifBlank { product.supplier },
                            unit = unit.ifBlank { product.unit },
                            minStock = minStock.toDoubleOrNull() ?: product.minStock,
                            price = price.toDoubleOrNull() ?: product.price,
                        ),
                    )
                },
                style = ButtonStyle.PRIMARY,
            )
        },
        dismissButton = {
            AppButton(text = "Отмена", onClick = onDismiss, style = ButtonStyle.OUTLINED)
        },
    )
}
