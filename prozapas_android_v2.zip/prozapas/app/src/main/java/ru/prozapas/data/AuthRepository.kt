package ru.prozapas.data

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/** SHA-256 с солью приложения. */
object PasswordHash {
    fun sha256(pw: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("prozapas::$pw".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

/**
 * Репозиторий учётных записей. Первая регистрация получает роль РУКОВОДИТЕЛЬ,
 * остальные — ТОВАРОВЕД (роль меняет руководитель). Хранится в SharedPreferences.
 */
class AuthRepository(private val prefs: SharedPreferences) {
    private val _users = MutableStateFlow(loadUsers())
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _currentUser = MutableStateFlow(loadCurrentUser())
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private var nextId: Long = (_users.value.maxOfOrNull { it.id } ?: 0L) + 1L

    fun register(name: String, login: String, pw: String): Result<User> {
        val trimmedName = name.trim()
        val trimmedLogin = login.trim().lowercase()
        if (trimmedName.isEmpty() || trimmedLogin.isEmpty()) {
            return Result.failure(IllegalArgumentException("Заполните имя и логин"))
        }
        if (pw.length < 4) {
            return Result.failure(IllegalArgumentException("Пароль должен быть не короче 4 символов"))
        }
        if (_users.value.any { it.login == trimmedLogin }) {
            return Result.failure(IllegalArgumentException("Такой логин уже занят"))
        }
        val role = if (_users.value.isEmpty()) Role.ADMIN else Role.TOVAR
        val user = User(
            id = nextId++,
            name = trimmedName,
            login = trimmedLogin,
            pwHash = PasswordHash.sha256(pw),
            role = role,
            createdAt = System.currentTimeMillis(),
        )
        _users.value = _users.value + user
        persistUsers()
        _currentUser.value = user
        persistSession()
        return Result.success(user)
    }

    fun login(login: String, pw: String): Result<User> {
        val trimmedLogin = login.trim().lowercase()
        val user = _users.value.firstOrNull { it.login == trimmedLogin }
            ?: return Result.failure(IllegalArgumentException("Неверный логин или пароль"))
        if (user.pwHash != PasswordHash.sha256(pw)) {
            return Result.failure(IllegalArgumentException("Неверный логин или пароль"))
        }
        _currentUser.value = user
        persistSession()
        return Result.success(user)
    }

    fun logout() {
        _currentUser.value = null
        prefs.edit().remove(KEY_SESSION).apply()
    }

    fun setRole(id: Long, role: Role) {
        val admins = _users.value.count { it.role == Role.ADMIN }
        val user = _users.value.firstOrNull { it.id == id } ?: return
        if (user.id == currentUserId() && role != Role.ADMIN && admins <= 1) return
        _users.value = _users.value.map { if (it.id == id) it.copy(role = role) else it }
        persistUsers()
    }

    fun resetPassword(id: Long, pw: String): Boolean {
        if (pw.length < 4) return false
        _users.value = _users.value.map { if (it.id == id) it.copy(pwHash = PasswordHash.sha256(pw)) else it }
        persistUsers()
        return true
    }

    fun renameUser(id: Long, name: String) {
        if (name.isBlank()) return
        _users.value = _users.value.map { if (it.id == id) it.copy(name = name.trim()) else it }
        persistUsers()
    }

    fun deleteUser(id: Long): Boolean {
        if (id == currentUserId()) return false
        _users.value = _users.value.filterNot { it.id == id }
        persistUsers()
        return true
    }

    fun addAccount(name: String, login: String, pw: String, role: Role): Result<User> {
        val trimmedLogin = login.trim().lowercase()
        if (name.isBlank() || trimmedLogin.isEmpty()) {
            return Result.failure(IllegalArgumentException("Заполните имя и логин"))
        }
        if (pw.length < 4) {
            return Result.failure(IllegalArgumentException("Пароль должен быть не короче 4 символов"))
        }
        if (_users.value.any { it.login == trimmedLogin }) {
            return Result.failure(IllegalArgumentException("Такой логин уже занят"))
        }
        val user = User(nextId++, name.trim(), trimmedLogin, PasswordHash.sha256(pw), role, System.currentTimeMillis())
        _users.value = _users.value + user
        persistUsers()
        return Result.success(user)
    }

    private fun currentUserId(): Long? = _currentUser.value?.id

    private fun persistUsers() {
        val array = JSONArray()
        _users.value.forEach { user ->
            array.put(
                JSONObject()
                    .put("id", user.id)
                    .put("name", user.name)
                    .put("login", user.login)
                    .put("pwHash", user.pwHash)
                    .put("role", user.role.name)
                    .put("createdAt", user.createdAt),
            )
        }
        prefs.edit().putString(KEY_USERS, array.toString()).apply()
    }

    private fun persistSession() {
        val id = currentUserId()
        prefs.edit().putString(KEY_SESSION, id?.toString()).apply()
    }

    private fun loadUsers(): List<User> = try {
        val raw = prefs.getString(KEY_USERS, null)
        if (raw.isNullOrBlank()) {
            emptyList()
        } else {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                User(
                    id = obj.getLong("id"),
                    name = obj.getString("name"),
                    login = obj.getString("login"),
                    pwHash = obj.getString("pwHash"),
                    role = Role.fromName(obj.getString("role")),
                    createdAt = obj.optLong("createdAt", 0L),
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun loadCurrentUser(): User? {
        val id = prefs.getString(KEY_SESSION, null)?.toLongOrNull() ?: return null
        return loadUsers().firstOrNull { it.id == id }
    }

    private companion object {
        const val KEY_USERS = "prozapas_users"
        const val KEY_SESSION = "prozapas_session"
    }
}
