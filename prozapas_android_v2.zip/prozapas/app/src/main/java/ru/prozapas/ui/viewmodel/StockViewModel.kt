package ru.prozapas.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ru.prozapas.data.HistoryEvent
import ru.prozapas.data.OperationBus
import ru.prozapas.data.Product
import ru.prozapas.data.WarehouseRepository

/** Состояния экрана склада: Загрузка / Успех / Обновление / Ошибка (лаба 7). */
sealed interface StockUiState {
    data object Loading : StockUiState
    data class Success(val cachedAt: Long, val visibleCount: Int) : StockUiState
    data class Refreshing(val cachedAt: Long, val visibleCount: Int) : StockUiState
    data class Error(
        val message: String,
        val retryCount: Int,
        val retryDelayMs: Long,
    ) : StockUiState
}

/**
 * ViewModel экрана склада. Логика загрузки, пагинации, фильтрации и прав
 * — здесь, UI только читает состояние (лабораторная работа 7).
 */
class StockViewModel(private val repository: WarehouseRepository) : ViewModel() {
    val products = repository.products
    val history = repository.history

    private val _state = MutableStateFlow<StockUiState>(StockUiState.Loading)
    val state: StateFlow<StockUiState> = _state.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _category = MutableStateFlow("")
    val category: StateFlow<String> = _category.asStateFlow()

    private val _lowOnly = MutableStateFlow(false)
    val lowOnly: StateFlow<Boolean> = _lowOnly.asStateFlow()

    private var isRequestActive = false
    private var retryCount = 0

    fun load() {
        if (isRequestActive) return
        isRequestActive = true
        retryCount = 0
        _state.value = StockUiState.Loading
        viewModelScope.launch {
            delay(400)
            repository.initialLoad().fold(
                onSuccess = { finishWith() },
                onFailure = { failWith(it) },
            )
        }
    }

    fun refresh() {
        if (isRequestActive) return
        val current = _state.value
        if (current !is StockUiState.Success) {
            load()
            return
        }
        isRequestActive = true
        _state.value = StockUiState.Refreshing(current.cachedAt, current.visibleCount)
        viewModelScope.launch {
            delay(400)
            repository.refresh().fold(
                onSuccess = { finishWith() },
                onFailure = { failWith(it) },
            )
        }
    }

    /** Повтор с экспоненциальной задержкой: 1с, 2с, 4с (лаба 7, задание 2). */
    fun retry() {
        if (isRequestActive) return
        val delayMs = if (retryCount > 1) backoffMs() else 0L
        viewModelScope.launch {
            if (delayMs > 0) delay(delayMs)
            performRequest()
        }
    }

    private fun backoffMs(): Long = (1L shl (retryCount - 1).coerceIn(0, 3)) * 1000L

    private fun performRequest() {
        if (isRequestActive) return
        isRequestActive = true
        _state.value = StockUiState.Loading
        viewModelScope.launch {
            delay(400)
            repository.initialLoad().fold(
                onSuccess = { finishWith() },
                onFailure = { failWith(it) },
            )
        }
    }

    private fun finishWith() {
        isRequestActive = false
        retryCount = 0
        _state.value = StockUiState.Success(
            cachedAt = System.currentTimeMillis(),
            visibleCount = PAGE_SIZE,
        )
    }

    private fun failWith(t: Throwable) {
        isRequestActive = false
        retryCount += 1
        _state.value = StockUiState.Error(
            message = t.message ?: "Неизвестная ошибка",
            retryCount = retryCount,
            retryDelayMs = if (retryCount > 1) backoffMs() else 0L,
        )
    }

    fun loadMore() {
        val current = _state.value
        if (current is StockUiState.Success && current.visibleCount < products.value.size) {
            _state.value = current.copy(visibleCount = current.visibleCount + PAGE_SIZE)
        }
    }

    fun onQueryChange(value: String) { _query.value = value }

    fun setCategory(value: String) { _category.value = value }

    fun setLowOnly(value: Boolean) { _lowOnly.value = value }

    /** «Поиск на сервере» с эмуляцией задержки (лаба 9, модуль 2). */
    suspend fun searchRemote(q: String) = repository.remoteSearch(q)

    fun changeStock(id: Long, delta: Double, actor: String) {
        if (!actorRoleCanEditStock) return
        val name = products.value.firstOrNull { it.id == id }?.name ?: return
        repository.changeStock(id, delta)
        repository.log(
            (if (delta > 0) "Приход" else "Списание") + ": " + name + " — " + actor,
        )
        OperationBus.push(if (delta > 0) "Приход: $name" else "Списание: $name")
    }

    fun upsert(product: Product, actor: String) {
        val isNew = products.value.none { it.id == product.id }
        repository.upsert(product)
        repository.log(if (isNew) "Добавлен товар: ${product.name} — $actor" else "Изменён товар: ${product.name} — $actor")
    }

    fun deleteProduct(id: Long, actor: String) {
        val name = products.value.firstOrNull { it.id == id }?.name ?: return
        repository.delete(id)
        repository.log("Удалён товар: $name — $actor")
        OperationBus.push("Удалён товар: $name")
    }

    var actorRoleCanEditStock: Boolean = true
    var actorRoleCanViewPrices: Boolean = true
    var actorRoleCanPurchase: Boolean = true
    var actorRoleCanManageUsers: Boolean = false

    companion object {
        const val PAGE_SIZE = 20
    }
}
