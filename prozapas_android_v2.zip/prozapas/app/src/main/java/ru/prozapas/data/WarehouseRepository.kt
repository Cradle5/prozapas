package ru.prozapas.data

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.IOException
import kotlin.random.Random

/** Шина событий склада: подписка/отписка для DisposableEffect (лабораторная работа 9). */
object OperationBus {
    private val listeners = mutableSetOf<(String) -> Unit>()

    fun subscribe(listener: (String) -> Unit) {
        listeners += listener
    }

    fun unsubscribe(listener: (String) -> Unit) {
        listeners -= listener
    }

    fun push(message: String) {
        listeners.forEach { it(message) }
    }

    fun listenerCount(): Int = listeners.size
}

/** Контракт репозитория склада. ViewModel не знает о деталях реализации. */
interface WarehouseRepository {
    val products: StateFlow<List<Product>>
    val history: StateFlow<List<HistoryEvent>>

    suspend fun initialLoad(): Result<List<Product>>
    suspend fun refresh(): Result<List<Product>>
    suspend fun remoteSearch(query: String)
    fun changeStock(id: Long, delta: Double)
    fun upsert(product: Product)
    fun delete(id: Long)
    fun log(text: String)
}

/**
 * Демонстрационный репозиторий склада. Имитирует нестабильную сеть:
 * задержка и случайные ошибки (лабораторная работа 7).
 */
class FakeWarehouseRepository : WarehouseRepository {
    private val _products = MutableStateFlow<List<Product>>(emptyList())
    override val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _history = MutableStateFlow<List<HistoryEvent>>(emptyList())
    override val history: StateFlow<List<HistoryEvent>> = _history.asStateFlow()

    private var nextHistoryId = 1L

    /** Флаг для детерминированных unit-тестов. */
    var failNextLoad = false

    /** Счётчик вызовов начальной загрузки — для теста защиты от дублей. */
    var loadCalls = 0

    override suspend fun initialLoad(): Result<List<Product>> {
        loadCalls += 1
        delay(900)
        if (failNextLoad) {
            failNextLoad = false
            return Result.failure(IOException("Нет соединения с сервером"))
        }
        if (_products.value.isEmpty()) {
            _products.value = demoProducts()
        }
        return Result.success(_products.value)
    }

    override suspend fun refresh(): Result<List<Product>> {
        delay(700)
        if (failNextLoad) {
            failNextLoad = false
            return Result.failure(IOException("Нет соединения с сервером"))
        }
        if (Random.nextFloat() < 0.2f) {
            return Result.failure(IOException("Сервер недоступен, повторите позже"))
        }
        if (_products.value.isEmpty()) {
            _products.value = demoProducts()
        }
        return Result.success(_products.value)
    }

    override suspend fun remoteSearch(query: String) {
        delay(250)
        android.util.Log.d("PROZAPAS", "remoteSearch: \"$query\"")
    }

    override fun changeStock(id: Long, delta: Double) {
        _products.update { list ->
            list.map { if (it.id == id) it.withStock(it.stock + delta) else it }
        }
    }

    override fun upsert(product: Product) {
        _products.update { list ->
            val index = list.indexOfFirst { it.id == product.id }
            if (index >= 0) {
                val copy = list.toMutableList()
                copy[index] = product
                copy
            } else {
                list + product
            }
        }
    }

    override fun delete(id: Long) {
        _products.update { list -> list.filterNot { it.id == id } }
    }

    override fun log(text: String) {
        val event = HistoryEvent(nextHistoryId++, System.currentTimeMillis(), text)
        _history.update { list -> listOf(event) + list }
    }
}

/** Демонстрационные данные: 60 позиций с детерминированным случайным наполнением. */
fun demoProducts(): List<Product> {
    val categories = listOf("Бакалея", "Молочное", "Напитки", "Расходники", "Хозтовары")
    val suppliers = listOf("ООО «Агро-Трейд»", "Coffee Import LLC", "ООО «МолокоПлюс»", "Упак-Сервис")
    val units = listOf("шт", "кг", "л", "уп")
    val rand = Random(42)
    return (1L..60L).map { id ->
        Product(
            id = id,
            name = "Товар №$id",
            sku = "ART-" + id.toString().padStart(4, '0'),
            category = categories[((id - 1) % categories.size).toInt()],
            unit = units[((id - 1) % units.size).toInt()],
            price = rand.nextInt(50, 1500).toDouble(),
            stock = rand.nextInt(0, 41).toDouble(),
            minStock = rand.nextInt(4, 16).toDouble(),
            supplier = suppliers[((id - 1) % suppliers.size).toInt()],
        )
    }
}
