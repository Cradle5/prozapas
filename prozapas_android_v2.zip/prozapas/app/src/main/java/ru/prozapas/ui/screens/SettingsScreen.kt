package ru.prozapas.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import ru.prozapas.data.Role
import ru.prozapas.data.ThemeMode
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.ProZapasHeader
import ru.prozapas.ui.viewmodel.SettingsViewModel

/**
 * Экран «Настройки» (лаба 6): управление темой из UI (лаба 8, задание 3),
 * принудительно тёмный контент, выход из системы.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    val viewModel: SettingsViewModel = viewModel {
        SettingsViewModel(ServiceLocator.container.settingsStore)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val currentUser by ServiceLocator.container.authRepository.currentUser.collectAsStateWithLifecycle()
    val role = currentUser?.role ?: Role.TOVAR

    Column(modifier = Modifier.fillMaxSize()) {
        ProZapasHeader(
            title = "Настройки",
            actions = {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                }
            },
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Тема оформления", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = state.themeMode == ThemeMode.SYSTEM,
                    onClick = { viewModel.setThemeMode(ThemeMode.SYSTEM) },
                    label = { Text("Системная") },
                )
                FilterChip(
                    selected = state.themeMode == ThemeMode.LIGHT,
                    onClick = { viewModel.setThemeMode(ThemeMode.LIGHT) },
                    label = { Text("Светлая") },
                )
                FilterChip(
                    selected = state.themeMode == ThemeMode.DARK,
                    onClick = { viewModel.setThemeMode(ThemeMode.DARK) },
                    label = { Text("Тёмная") },
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Принудительно тёмный контент", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Имитация высококонтрастного режима",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = state.forceDarkContent,
                    onCheckedChange = viewModel::setForceDarkContent,
                )
            }
            HorizontalDivider()
            Text("Разделы", style = MaterialTheme.typography.titleLarge)
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Мой профиль",
                onClick = { navController.navigate("profile") },
                style = ButtonStyle.SECONDARY,
            )
            if (role.canManageUsers) {
                AppButton(
                    modifier = Modifier.fillMaxWidth(),
                    text = "Пользователи и роли",
                    onClick = { navController.navigate("users") },
                    style = ButtonStyle.SECONDARY,
                )
            }
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Каталог постов (демо API)",
                onClick = { navController.navigate("posts") },
                style = ButtonStyle.OUTLINED,
            )
            AppButton(
                modifier = Modifier.fillMaxWidth(),
                text = "Выйти из системы",
                onClick = {
                    ServiceLocator.container.authRepository.logout()
                    navController.navigate("auth") { popUpTo(0) { inclusive = true } }
                },
                style = ButtonStyle.OUTLINED,
            )
            Text(
                "Тема сохраняется между запусками приложения",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
