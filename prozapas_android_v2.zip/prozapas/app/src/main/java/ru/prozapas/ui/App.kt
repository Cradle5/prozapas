package ru.prozapas.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import ru.prozapas.data.SettingsState
import ru.prozapas.di.ServiceLocator
import ru.prozapas.theme.AppTheme
import ru.prozapas.ui.screens.AuthScreen
import ru.prozapas.ui.screens.HomeScreen
import ru.prozapas.ui.screens.PostDetailScreen
import ru.prozapas.ui.screens.PostsScreen
import ru.prozapas.ui.screens.ProductDetailsScreen
import ru.prozapas.ui.screens.ProfileScreen
import ru.prozapas.ui.screens.PurchaseScreen
import ru.prozapas.ui.screens.SettingsScreen
import ru.prozapas.ui.screens.StockScreen
import ru.prozapas.ui.screens.UsersScreen
import ru.prozapas.ui.viewmodel.SettingsViewModel

/** Глобальное состояние настроек, доступное с любого экрана (лаба 6, задание 2). */
val LocalSettings = staticCompositionLocalOf { SettingsState() }

/** Провайдер настроек темы через ViewModel + CompositionLocal. */
@Composable
fun ProvideSettings(content: @Composable () -> Unit) {
    val viewModel: SettingsViewModel = viewModel {
        SettingsViewModel(ServiceLocator.container.settingsStore)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    CompositionLocalProvider(LocalSettings provides state) {
        content()
    }
}

/** Корневая точка приложения: тема + граф навигации. */
@Composable
fun ProZapasApp() {
    ProvideSettings {
        val settings = LocalSettings.current
        val darkTheme = when (settings.themeMode) {
            ru.prozapas.data.ThemeMode.SYSTEM -> isSystemInDarkTheme()
            ru.prozapas.data.ThemeMode.LIGHT -> false
            ru.prozapas.data.ThemeMode.DARK -> true
        }
        AppTheme(darkTheme = darkTheme, forceDarkContent = settings.forceDarkContent) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background,
            ) {
                ProZapasNavGraph()
            }
        }
    }
}

/**
 * Граф навигации (лабораторная работа 6):
 * auth → home → stock → product/{productId} (deep link app://myapp/product/{id}),
 * purchase, profile, settings, users, posts, post/{postId}.
 */
@Composable
fun ProZapasNavGraph() {
    val navController = rememberNavController()
    val currentUser by ServiceLocator.container.authRepository.currentUser.collectAsStateWithLifecycle()
    val startDestination = if (currentUser != null) "home" else "auth"

    NavHost(navController = navController, startDestination = startDestination) {
        composable("auth") {
            AuthScreen(
                onAuthSuccess = {
                    navController.navigate("home") {
                        popUpTo("auth") { inclusive = true }
                    }
                },
            )
        }
        composable("home") { HomeScreen(navController) }
        composable("stock") { StockScreen(navController) }
        composable(
            route = "product/{productId}",
            arguments = listOf(navArgument("productId") { type = NavType.LongType }),
            deepLinks = listOf(navDeepLink { uriPattern = "app://myapp/product/{productId}" }),
        ) { backStackEntry ->
            ProductDetailsScreen(
                navController = navController,
                productId = backStackEntry.arguments?.getLong("productId") ?: -1L,
            )
        }
        composable("purchase") { PurchaseScreen(navController) }
        composable("profile") { ProfileScreen(navController) }
        composable("settings") { SettingsScreen(navController) }
        composable("users") { UsersScreen(navController) }
        composable("posts") { PostsScreen(navController) }
        composable(
            route = "post/{postId}",
            arguments = listOf(navArgument("postId") { type = NavType.IntType }),
        ) { backStackEntry ->
            PostDetailScreen(
                savedStateHandle = backStackEntry.savedStateHandle,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
