package ru.prozapas.data.network

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/** Retrofit-интерфейс API (лабораторная работа 10). */
interface PostsApi {
    @GET("posts")
    suspend fun getPosts(
        @Query("_start") start: Int = 0,
        @Query("_limit") limit: Int = 20,
    ): List<Post>

    @GET("posts/{id}")
    suspend fun getPost(@Path("id") id: Int): Post

    @GET("posts/{id}/comments")
    suspend fun getComments(@Path("id") id: Int): List<Comment>
}
