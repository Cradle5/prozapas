package ru.prozapas.data.network

import retrofit2.HttpException
import java.io.IOException

/** Типизированные ошибки сети (лаба 10, PRO-уровень): сеть / HTTP / разбор. */
sealed class ApiError(message: String) : Exception(message) {
    class Network(val ioCause: IOException) : ApiError("Нет сети. Проверьте подключение")
    class Http(val code: Int) : ApiError("Сервер недоступен, попробуйте позже (код $code)")
    data object Parsing : ApiError("Ошибка разбора данных")

    fun userMessage(): String = message ?: "Неизвестная ошибка"
}

/** Репозиторий определён интерфейсом: ViewModel не знает о Retrofit. */
interface PostsRepository {
    suspend fun getPosts(page: Int, pageSize: Int = 20): Result<List<Post>>
    suspend fun getPost(id: Int): Result<Post>
    suspend fun getComments(id: Int): Result<List<Comment>>
}

class RetrofitPostsRepository(private val api: PostsApi) : PostsRepository {

    override suspend fun getPosts(page: Int, pageSize: Int): Result<List<Post>> = try {
        Result.success(api.getPosts(start = page * pageSize, limit = pageSize))
    } catch (e: IOException) {
        Result.failure(ApiError.Network(e))
    } catch (e: HttpException) {
        Result.failure(ApiError.Http(e.code()))
    } catch (e: Exception) {
        Result.failure(ApiError.Parsing)
    }

    override suspend fun getPost(id: Int): Result<Post> = try {
        Result.success(api.getPost(id))
    } catch (e: IOException) {
        Result.failure(ApiError.Network(e))
    } catch (e: HttpException) {
        Result.failure(ApiError.Http(e.code()))
    } catch (e: Exception) {
        Result.failure(ApiError.Parsing)
    }

    override suspend fun getComments(id: Int): Result<List<Comment>> = try {
        Result.success(api.getComments(id))
    } catch (e: IOException) {
        Result.failure(ApiError.Network(e))
    } catch (e: HttpException) {
        Result.failure(ApiError.Http(e.code()))
    } catch (e: Exception) {
        Result.failure(ApiError.Parsing)
    }
}
