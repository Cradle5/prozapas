package ru.prozapas.di

import android.content.Context
import android.content.SharedPreferences
import ru.prozapas.data.AuthRepository
import ru.prozapas.data.FakeWarehouseRepository
import ru.prozapas.data.SettingsStore
import ru.prozapas.data.WarehouseRepository
import ru.prozapas.data.network.PostsRepository
import ru.prozapas.data.network.RetrofitClient
import ru.prozapas.data.network.RetrofitPostsRepository

/** Ручной DI: контейнер зависимостей (лаба 10 — ViewModel без Retrofit-типов). */
class AppContainer(context: Context) {
    val prefs: SharedPreferences = context.getSharedPreferences("prozapas_prefs", Context.MODE_PRIVATE)
    val settingsStore = SettingsStore(prefs)
    val warehouseRepository: WarehouseRepository = FakeWarehouseRepository()
    val authRepository = AuthRepository(prefs)
    val postsRepository: PostsRepository = RetrofitPostsRepository(RetrofitClient.api)
}

object ServiceLocator {
    lateinit var container: AppContainer
        private set

    fun init(context: Context) {
        if (!::container.isInitialized) {
            container = AppContainer(context.applicationContext)
        }
    }
}
