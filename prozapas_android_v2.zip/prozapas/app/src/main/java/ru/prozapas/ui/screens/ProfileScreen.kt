package ru.prozapas.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.prozapas.data.ProductStatus
import ru.prozapas.di.ServiceLocator
import ru.prozapas.theme.ProZapasColors
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.AvatarPlaceholder
import ru.prozapas.ui.components.ButtonSize
import ru.prozapas.ui.components.ButtonState
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.FormField
import ru.prozapas.ui.components.LoadingButton
import ru.prozapas.ui.components.ProfileCard
import ru.prozapas.ui.components.ProZapasHeader
import ru.prozapas.ui.components.SnackbarLikeMessage
import ru.prozapas.ui.components.StatusButton
import ru.prozapas.ui.util.formatRub

/**
 * Экран «Мой профиль»: макет лабораторной работы 3 (аватар 64dp, счётчики,
 * нижняя панель из трёх иконок, BoxWithConstraints) + компоненты лабы 8
 * (ProfileCard, AppButton-группа, LoadingButton, StatusButton, живой регион).
 */
@Composable
fun ProfileScreen(navController: NavController) {
    val authRepository = ServiceLocator.container.authRepository
    val currentUser by authRepository.currentUser.collectAsStateWithLifecycle()
    val user = currentUser
    if (user == null) {
        Box(modifier = Modifier.fillMaxSize())
        LaunchedEffect(Unit) {
            navController.navigate("auth") { popUpTo(0) { inclusive = true } }
        }
        return
    }

    val products by ServiceLocator.container.warehouseRepository.products.collectAsStateWithLifecycle()
    val history by ServiceLocator.container.warehouseRepository.history.collectAsStateWithLifecycle()

    var newName by rememberSaveable { mutableStateOf(user.name) }
    var saving by remember { mutableStateOf(false) }
    var saveState by remember { mutableStateOf(ButtonState.IDLE) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(message) {
        if (message != null) {
            delay(2500)
            message = null
        }
    }

    fun saveName() {
        if (newName.isBlank() || newName == user.name) {
            message = "Введите новое имя"
            return
        }
        saving = true
        saveState = ButtonState.LOADING
        scope.launch {
            delay(900)
            authRepository.renameUser(user.id, newName)
            saving = false
            saveState = ButtonState.SUCCESS
            message = "Изменения сохранены"
        }
    }

    val positions = products.size
    val deficit = products.count { it.status != ProductStatus.OK }
    val totalValue = products.sumOf { it.price * it.stock }
    val role = user.role

    Column(modifier = Modifier.fillMaxSize()) {
        ProZapasHeader(title = "Мой профиль", subtitle = "Прозапас \u00B7 версия 2.0")
        BoxWithConstraints(modifier = Modifier.fillMaxWidth().weight(1f)) {
            val wide = maxWidth >= 600.dp
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                SnackbarLikeMessage(message = message)
                if (wide) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AvatarPlaceholder(
                            initial = user.name.firstOrNull()?.uppercase() ?: "?",
                            modifier = Modifier.size(64.dp),
                        )
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(user.name, style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "Статус: ${role.label}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        AvatarPlaceholder(
                            initial = user.name.firstOrNull()?.uppercase() ?: "?",
                            modifier = Modifier.size(64.dp),
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(user.name, style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Статус: ${role.label}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text(positions.toString(), style = MaterialTheme.typography.titleLarge)
                        Text("Позиций", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            deficit.toString(),
                            style = MaterialTheme.typography.titleLarge,
                            color = if (deficit > 0) ProZapasColors.low else Color.Unspecified,
                        )
                        Text("С дефицитом", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                ProfileCard(
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    title = user.name,
                    subtitle = "Роль: ${role.label} \u00B7 логин: ${user.login}",
                    trailingContent = {
                        IconButton(onClick = { message = "Редактирование \u2014 в поле ниже" }) {
                            Icon(Icons.Default.Edit, contentDescription = "Редактировать профиль")
                        }
                    },
                )

                Text("Статистика", style = MaterialTheme.typography.titleLarge)
                Text("Позиций на складе: $positions", style = MaterialTheme.typography.bodyLarge)
                Text("Позиций с дефицитом: $deficit", style = MaterialTheme.typography.bodyLarge)
                if (role.canViewPrices) {
                    Text("Стоимость запаса: ${totalValue.formatRub()}", style = MaterialTheme.typography.bodyLarge)
                }
                Text("Операций в истории: ${history.size}", style = MaterialTheme.typography.bodyLarge)

                Text("Профиль", style = MaterialTheme.typography.titleLarge)
                FormField(
                    modifier = Modifier.fillMaxWidth(),
                    value = newName,
                    onValueChange = { newName = it },
                    label = "Фамилия и имя",
                )
                LoadingButton(
                    text = "Сохранить изменения",
                    onClick = { saveName() },
                    isLoading = saving,
                    modifier = Modifier.fillMaxWidth(),
                )
                AppButton(
                    modifier = Modifier.fillMaxWidth(),
                    text = "Отмена",
                    onClick = { newName = user.name; saveState = ButtonState.IDLE; saving = false },
                    style = ButtonStyle.SECONDARY,
                )
                AppButton(
                    text = "Сбросить",
                    onClick = { newName = ""; message = null },
                    style = ButtonStyle.OUTLINED,
                    size = ButtonSize.SMALL,
                )
                StatusButton(
                    text = "Сохранить статус",
                    state = saveState,
                    onClick = { saveName() },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Default.Home, contentDescription = "На главную")
            }
            IconButton(onClick = { navController.navigate("settings") }) {
                Icon(Icons.Default.Settings, contentDescription = "Настройки")
            }
            IconButton(onClick = {
                authRepository.logout()
                navController.navigate("auth") { popUpTo(0) { inclusive = true } }
            }) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Выйти из системы")
            }
        }
    }
}
