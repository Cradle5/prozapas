package ru.prozapas.data

data class User(
    val id: Long,
    val name: String,
    val login: String,
    val pwHash: String,
    val role: Role,
    val createdAt: Long,
)
