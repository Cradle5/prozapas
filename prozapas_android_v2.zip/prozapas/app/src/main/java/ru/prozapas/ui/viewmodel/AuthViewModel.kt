package ru.prozapas.ui.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.StateFlow
import ru.prozapas.data.AuthRepository
import ru.prozapas.data.User

/** ViewModel авторизации и регистрации (лабы 6-7: экран входа в систему). */
class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    val currentUser: StateFlow<User?> = repository.currentUser

    fun login(login: String, pw: String, onResult: (String?) -> Unit) {
        repository.login(login, pw).fold(
            onSuccess = { onResult(null) },
            onFailure = { onResult(it.message ?: "Ошибка") },
        )
    }

    fun register(name: String, login: String, pw: String, pwConfirm: String, onResult: (String?) -> Unit) {
        if (pw != pwConfirm) {
            onResult("Пароли не совпадают")
            return
        }
        repository.register(name, login, pw).fold(
            onSuccess = { onResult(null) },
            onFailure = { onResult(it.message ?: "Ошибка") },
        )
    }
}
