package ru.prozapas.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import ru.prozapas.di.ServiceLocator
import ru.prozapas.ui.components.AppButton
import ru.prozapas.ui.components.ButtonSize
import ru.prozapas.ui.components.ButtonStyle
import ru.prozapas.ui.components.ProZapasHeader
import ru.prozapas.ui.util.formatQty
import ru.prozapas.ui.util.formatRub
import ru.prozapas.ui.viewmodel.PurchaseEntry
import ru.prozapas.ui.viewmodel.PurchaseViewModel

/**
 * Экран заявки на закупку: корзина с группировкой по поставщикам,
 * правка количеств, текст заявки с копированием, проведение прихода.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchaseScreen(navController: NavController) {
    val viewModel: PurchaseViewModel = viewModel {
        PurchaseViewModel(ServiceLocator.container.warehouseRepository)
    }
    val products by viewModel.products.collectAsStateWithLifecycle()
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val currentUser by ServiceLocator.container.authRepository.currentUser.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showOrder by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    val entries = cart.mapNotNull { (id, qty) ->
        products.firstOrNull { it.id == id }?.let { PurchaseEntry(it, qty) }
    }
    val groups = entries.groupBy { it.product.supplier.ifBlank { "Поставщик не указан" } }
    val total = entries.sumOf { it.product.price * it.qty }

    fun notify(message: String) {
        scope.launch { snackbarHostState.showSnackbar(message) }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            ProZapasHeader(
                title = "Заявка на закупку",
                subtitle = "Позиций: ${entries.size}",
                actions = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
            )
            if (entries.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Корзина пуста.\nДобавьте позиции со склада кнопкой «В заявку».",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                    groups.forEach { (supplier, list) ->
                        item(key = "section_$supplier") {
                            Text(
                                supplier,
                                style = MaterialTheme.typography.titleLarge,
                                modifier = Modifier
                                    .padding(start = 16.dp, top = 14.dp, bottom = 4.dp),
                            )
                        }
                        items(list, key = { it.product.id }) { entry ->
                            CartRow(
                                entry = entry,
                                onQtyChange = { value -> viewModel.setQty(entry.product.id, value) },
                                onRemove = { viewModel.remove(entry.product.id) },
                            )
                            HorizontalDivider()
                        }
                    }
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    "Итого",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    total.formatRub(),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                            AppButton(
                                modifier = Modifier.fillMaxWidth(),
                                text = "Дефицит \u2192 в заявку",
                                onClick = {
                                    if (!viewModel.hasDeficit()) {
                                        notify("Дефицита нет — все остатки в норме")
                                    } else {
                                        viewModel.autofillDeficit()
                                        notify("Дефицит добавлен в заявку")
                                    }
                                },
                                style = ButtonStyle.OUTLINED,
                            )
                            AppButton(
                                modifier = Modifier.fillMaxWidth(),
                                text = "Сформировать заявку",
                                onClick = { showOrder = true },
                                style = ButtonStyle.PRIMARY,
                                size = ButtonSize.LARGE,
                            )
                            AppButton(
                                modifier = Modifier.fillMaxWidth(),
                                text = "Провести приход",
                                onClick = { showConfirm = true },
                                style = ButtonStyle.SECONDARY,
                            )
                        }
                    }
                }
            }
        }
    }

    if (showOrder) {
        val orderText = buildOrderText(groups, total)
        val clipboard = LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { showOrder = false },
            title = { Text("Заявка на закупку") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(orderText, style = MaterialTheme.typography.bodySmall)
                    AppButton(
                        modifier = Modifier.fillMaxWidth(),
                        text = "Скопировать текст",
                        onClick = {
                            clipboard.setText(AnnotatedString(orderText))
                            notify("Заявка скопирована в буфер обмена")
                        },
                        style = ButtonStyle.SECONDARY,
                        size = ButtonSize.SMALL,
                    )
                }
            },
            confirmButton = {
                AppButton(text = "Готово", onClick = { showOrder = false })
            },
        )
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("Провести приход?") },
            text = {
                Text("Остатки увеличатся на количества из заявки, операция попадёт в историю.")
            },
            confirmButton = {
                AppButton(text = "Провести") {
                    showConfirm = false
                    if (viewModel.receive(currentUser?.name ?: "—")) {
                        notify("Приход проведён")
                    }
                }
            },
            dismissButton = {
                AppButton(text = "Отмена", onClick = { showConfirm = false }, style = ButtonStyle.OUTLINED)
            },
        )
    }
}

@Composable
private fun CartRow(
    entry: PurchaseEntry,
    onQtyChange: (Double) -> Unit,
    onRemove: () -> Unit,
) {
    val initialText = if (entry.qty == entry.qty.toLong().toDouble()) {
        entry.qty.toLong().toString()
    } else {
        entry.qty.toString()
    }
    var qtyText by remember(entry.product.id, entry.qty) { mutableStateOf(initialText) }

    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                entry.product.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                "${entry.product.sku} · ${entry.product.price.formatRub()}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        OutlinedTextField(
            value = qtyText,
            onValueChange = { input ->
                qtyText = input
                input.toDoubleOrNull()?.let { onQtyChange(it) }
            },
            label = { Text(entry.product.unit) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.width(96.dp),
        )
        IconButton(onClick = onRemove) {
            Icon(Icons.Default.Delete, contentDescription = "Удалить из заявки")
        }
    }
}

private fun buildOrderText(
    groups: Map<String, List<PurchaseEntry>>,
    total: Double,
): String {
    val builder = StringBuilder("Заявка на закупку \u2014 Прозапас\n")
    builder.append("Дата: ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("ru", "RU")).format(java.util.Date())}\n")
    groups.forEach { (supplier, list) ->
        builder.append("\n").append(supplier).append(":\n")
        list.forEach { entry ->
            val sum = entry.product.price * entry.qty
            builder.append("  \u2022 ${entry.product.name} (${entry.product.sku}) \u2014 ")
                .append("${entry.qty.formatQty()} ${entry.product.unit} \u2014 ${sum.formatRub()}\n")
        }
    }
    builder.append("\nИтого: ${total.formatRub()}")
    return builder.toString()
}
