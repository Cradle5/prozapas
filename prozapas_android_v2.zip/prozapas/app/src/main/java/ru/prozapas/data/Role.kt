package ru.prozapas.data

/**
 * Роли пользователей системы. Права по роли:
 * - Руководитель — полный доступ;
 * - Бухгалтер — цены, закупки, приход;
 * - Товаровед — количественный учёт без цен.
 */
enum class Role(
    val label: String,
    val canViewPrices: Boolean,
    val canEditStock: Boolean,
    val canPurchase: Boolean,
    val canManageUsers: Boolean,
) {
    ADMIN("Руководитель", true, true, true, true),
    BUH("Бухгалтер", true, false, true, false),
    TOVAR("Товаровед", false, true, false, false);

    companion object {
        fun fromName(name: String): Role =
            entries.firstOrNull { it.name == name } ?: TOVAR
    }
}
