package ru.prozapas

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.navigation.compose.rememberNavController
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import ru.prozapas.di.ServiceLocator
import ru.prozapas.theme.AppTheme
import ru.prozapas.ui.screens.StockScreen

@RunWith(AndroidJUnit4::class)
class StockScreenTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Before
    fun setUp() {
        ServiceLocator.init(
            androidx.test.core.app.ApplicationProvider.getApplicationContext(),
        )
    }

    private fun setContent() {
        composeRule.setContent {
            AppTheme {
                StockScreen(navController = rememberNavController())
            }
        }
    }

    private fun waitText(text: String, timeoutMs: Long = 10_000) {
        composeRule.waitUntil(timeoutMillis = timeoutMs) {
            composeRule.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty()
        }
    }

    // Тест 1: список отрисовался после загрузки, строка доступна по testTag.
    @Test
    fun list_isRendered_afterLoad() {
        setContent()
        waitText("Показано: 20 из 60")
        composeRule.onNodeWithTag("productRow_1").assertIsDisplayed()
    }

    // Тест 2: поиск по артикулу фильтрует список (дебаунс ждём, а не спим).
    @Test
    fun search_bySku_filtersList() {
        setContent()
        waitText("Показано: 20 из 60")
        composeRule.onNodeWithTag("searchField").performTextClearance()
        composeRule.onNodeWithTag("searchField").performTextInput("ART-0042")
        waitText("Показано: 1 из 1")
        composeRule.onAllNodesWithText("ART-0001").fetchSemanticsNodes().isEmpty()
    }

    // Тест 3: «Загрузить ещё» добавляет страницу.
    @Test
    fun loadMore_addsPage() {
        setContent()
        waitText("Показано: 20 из 60")
        composeRule.onNodeWithTag("loadMore").performClick()
        waitText("Показано: 40 из 60")
    }

    // Тест 4: пустой поиск — состояние «Ничего не найдено».
    @Test
    fun search_withNoResults_showsEmptyState() {
        setContent()
        waitText("Показано: 20 из 60")
        composeRule.onNodeWithTag("searchField").performTextClearance()
        composeRule.onNodeWithTag("searchField").performTextInput("ZZZZZZ")
        waitText("Ничего не найдено")
    }
}
