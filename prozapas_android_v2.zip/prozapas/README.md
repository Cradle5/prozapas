# Прозапас — Android (Jetpack Compose)

**Управление товарными запасами и закупками.** Учебный проект: система контроля остатков
на складе и заявок на закупку, реализованная на Jetpack Compose по заданиям
лабораторных работ 1–10 (задания выполнялись «по выбранной теме студентов» — тема: склад).

## Как открыть

1. Android Studio → **Open** → папка проекта `prozapas`.
2. Дождаться синхронизации Gradle (обёртка настроена на Gradle 8.9, AGP 8.5.2, Kotlin 1.9.25).
3. Запустить на эмуляторе API 34+ или реальном устройстве (minSdk 24).

Примечание: в методичке лабы 1 указан `kotlinCompilerExtensionVersion = "1.5.17"` — такой
версии не существует; в проекте стоит корректная пара **Kotlin 1.9.25 + 1.5.15**.

## Как пользоваться

- Первый запуск: **Регистрация** — первая учётная запись получает роль **Руководитель**.
- Далее руководитель создаёт учётки в разделе «Пользователи» (роли: Руководитель, Бухгалтер, Товаровед).
- Роли: Бухгалтер — цены и закупки; Товаровед — количественный учёт без цен; Руководитель — всё.
- «В заявку» на складе добавляет позицию в заявку; «Дефицит → в заявку» автозаполняет;
  «Провести приход» увеличивает остатки и пишет в историю.

## Соответствие лабораторным работам

| Лаба | Тема | Где реализовано |
|---|---|---|
| 1 | Включение Compose, первый экран | `app/build.gradle.kts`, `MainActivity.kt`, тема `ui/theme` |
| 2 | Декларативный UI | все экраны `ui/screens/*` (State → UI) |
| 3 | Компоновка | `ProfileScreen.kt` (макет «Профиль»: аватар 64dp, счётчики со Spacer(weight), нижняя панель SpaceEvenly, BoxWithConstraints > 600dp) |
| 4 | Состояние и hoisting | счётчики остатков (+/−1), stateless-поиск, раскрытие карточек товара (ExpandableCard), «только дефицит» (чекбокс-фильтр) |
| 5 | Списки и Lazy-компоненты | `StockScreen.kt`: LazyColumn 60 позиций, разделители, «Загрузить ещё» (+20), «Больше нет данных», категории, позиция скролла не сбрасывается |
| 6 | Навигация | `ui/App.kt`: 9 маршрутов, аргумент `productId`, deep link `app://myapp/product/{id}`, возврат/очистка, настройки через CompositionLocal (LocalSettings), ViewModel'ы, SavedStateHandle на деталях поста |
| 7 | Состояния и ViewModel | `StockViewModel.kt`: Loading/Success/Refreshing/Error, эмуляция сети (задержка + 20% случайных ошибок), «Обновить», backoff 1/2/4/8 с, полупрозрачный оверлей обновления, юнит-тесты |
| 8 | Material 3 и компоненты | `theme/*` (AppTheme, ExtendedColors, Typography, Shapes), компоненты `ui/components/*`: AppButton (3 стиля × 3 размера), ProfileCard (слоты, mergeDescendants), FormField (4 состояния), StatusButton, LoadingButton, PulsingDots, SnackbarLikeMessage (liveRegion), адаптивный профиль |
| 9 | Анимации, эффекты, тесты, производительность | анимации: animateColorAsState/animateDpAsState/AnimatedVisibility/animateContentSize/PulsingDots (rememberInfiniteTransition) на складе; эффекты: LaunchedEffect(Unit) для загрузки, debounce поиска 300 мс, DisposableEffect + OperationBus, SideEffect-аналитика без дублей, collectAsStateWithLifecycle; тесты: `StockScreenTest` (4 instrumented); производительность: `key` в items, `@Immutable` модели, `derivedStateOf` (фильтр + кнопка «наверх») |
| 10 | Сеть (Retrofit) | «Каталог постов»: `data/network/*`, `PostsViewModel`, `PostDetailViewModel` (SavedStateHandle), три состояния, «Повторить», пагинация по 20, типизированные `ApiError`, ручной DI (`di/ServiceLocator`), интерфейс `PostsRepository` |

## Сборка и проверка

```bash
./gradlew :app:assembleDebug              # сборка
./gradlew test                            # юнит-тесты ViewModel
./gradlew :app:connectedDebugAndroidTest  # 4 instrumented-теста (нужен эмулятор)
adb shell am start -a android.intent.action.VIEW -d "app://myapp/product/3" ru.prozapas
```

## Структура

```
app/src/main/java/ru/prozapas/
  MainActivity.kt
  ui/            — навигация, экраны, компоненты, тема, утилиты
  ui/viewmodel/  — StockViewModel, PurchaseViewModel, AuthViewModel, UsersViewModel,
                   SettingsViewModel, PostsViewModel, PostDetailViewModel
  data/          — модели, FakeWarehouseRepository, AuthRepository, SettingsStore
  data/network/  — Retrofit-слой лабы 10
  di/            — ручной DI (AppContainer, ServiceLocator)
app/src/test/    — юнит-тесты ViewModel
app/src/androidTest/ — 4 Compose-теста экрана склада
```

## Честные оговорки

- Проект собирался вне Android Studio: перед сдачей запусти `./gradlew :app:assembleDebug`,
  чтобы убедиться в сборке; все версии зафиксированы в build-файлах.
- Instrumented-тесты запускаются только на эмуляторе/устройстве.
- Пароли хранятся как SHA-256 с солью в SharedPreferences — для учебного проекта этого
  достаточно; в проде так делать не надо.
